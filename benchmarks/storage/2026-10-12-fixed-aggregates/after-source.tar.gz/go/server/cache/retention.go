package cache

import (
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"hash/crc32"
	"os"
	"path/filepath"
	"strings"
	"time"
)

func (s *Store) prefix(branch Branch) string {
	if generation, ok := s.catalog.Generations[s.binding][branch]; ok {
		return branch.Prefix() + ".g" + hex.EncodeToString(generation[:])
	}
	return branch.Prefix()
}

// ApplyRetention performs a deliberate generation rewrite. No file is deleted
// until the catalog durably selects the replacement. Invalidation state and
// definition/shared-reference identities are not rolled off with event payloads.
func (s *Store) ApplyRetention() error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if e := s.check(); e != nil {
		return e
	}
	durations, e := s.policy.Retention.Durations()
	if e != nil {
		return e
	}
	for branch := Read; branch <= Trace; branch++ {
		if duration := durations[branch]; duration > 0 {
			if e = s.prune(branch, s.config.Now().Add(-duration)); e != nil {
				return s.fail(e)
			}
		}
	}
	return nil
}
func (s *Store) prune(branch Branch, cutoff time.Time) (err error) {
	old := s.branches[branch]
	if old == nil {
		return nil
	}
	if err = s.flush(old); err != nil {
		return err
	}
	changed := false
	for _, run := range old.runs {
		if run.MinMS < cutoff.UnixMilli() {
			changed = true
			break
		}
	}
	if !changed {
		return nil
	}
	// An index disabled after being populated must still obey retention. Load it
	// only for this maintenance operation, then release its in-memory directory.
	if branch == Write && s.objects == nil {
		if _, e := os.Stat(filepath.Join(s.collection, "nuts.idx")); e == nil {
			enabled := s.config.ObjectIndex
			s.config.ObjectIndex = true
			e = s.openObjects()
			s.config.ObjectIndex = enabled
			if e != nil {
				return e
			}
			defer func() {
				if s.objects != nil {
					e := s.objects.file.Close()
					s.objects = nil
					if err == nil {
						err = e
					}
				}
			}()
		} else if !os.IsNotExist(e) {
			return e
		}
	}
	oldPrefix := s.prefix(branch)
	var generation [16]byte
	if _, err = rand.Read(generation[:]); err != nil {
		return err
	}
	prefix := branch.Prefix() + ".g" + hex.EncodeToString(generation[:])
	base := filepath.Join(s.dir, prefix)
	replacement := &branchStore{branch: branch, generation: generation, time: newTimeTrie(), pendingIDs: map[[16]byte][]byte{}, popEnd: headerSize, sumEnd: headerSize}
	published := false
	var created []string
	defer func() {
		if !published {
			replacement.close()
			for _, path := range created {
				os.Remove(path)
			}
		}
	}()
	create := func(ext, magic string, width int) (*os.File, error) {
		path := base + ext
		created = append(created, path)
		return openFile(path, magic, s.layout.Digest, generation, width)
	}
	if replacement.idx, err = create(".idx", "NUTSIDX5", s.row.Width); err != nil {
		return err
	}
	if replacement.pop, err = create(".pop", "NUTSPOP5", 0); err != nil {
		return err
	}
	if replacement.tri, err = create(".tri", "TIMETRI5", s.row.Width); err != nil {
		return err
	}
	if old.sum != nil {
		if replacement.sum, err = create(".sum", "NUTSSUM5", 0); err != nil {
			return err
		}
	}
	var tail uint64
	for _, source := range old.runs {
		if source.MaxMS < cutoff.UnixMilli() {
			continue
		}
		start := lower(old.rows, s.row.Width, source.Start, source.End, cutoff.UnixMilli())
		if start == source.End {
			continue
		}
		var idx, pop []byte
		groups := map[aggregateKey]Aggregate{}
		minMS, maxMS := int64(0), int64(0)
		for number := start; number < source.End; number++ {
			row := append([]byte(nil), old.rows[number*uint64(s.row.Width):(number+1)*uint64(s.row.Width)]...)
			from, to := order.Uint64(row[s.row.Start:]), order.Uint64(row[s.row.End:])
			data, e := readBytes(old.pop, from, to)
			if e != nil {
				return e
			}
			next := replacement.popEnd + uint64(len(pop))
			order.PutUint64(row[s.row.Start:], next)
			order.PutUint64(row[s.row.End:], next+uint64(len(data)))
			for j, field := range []int{s.layout.Object, s.layout.Revision} {
				if field < 0 || s.layout.Widths[field] > 0 || State(row[s.row.Flags]>>uint(2*j)&3) != Offset {
					continue
				}
				slot := s.row.Object
				if j == 1 {
					slot = s.row.Revision
				}
				position := order.Uint64(row[slot:])
				length := order.Uint64(row[slot+8:])
				if position < from || position > to || length > to-position {
					return fmt.Errorf("invalid identity reference during retention")
				}
				order.PutUint64(row[slot:], next+(position-from))
			}
			ms := eventTime(row)
			if len(idx) == 0 {
				minMS = ms
			}
			maxMS = ms
			replacement.time.append(ms, tail+uint64(len(idx)/s.row.Width), s.location)
			if replacement.sum != nil {
				var frame Frame
				if e = s.layout.Scan(data, &frame); e != nil {
					return e
				}
				var duration *uint64
				if frame.Values[s.layout.Duration].State == Direct {
					d := unsigned(frame.Values[s.layout.Duration].Bytes)
					duration = &d
				}
				key := aggregateKey{ms / 300000 * 300000, order.Uint16(row[s.row.Reference:])}
				a := groups[key]
				if e = a.add(duration); e != nil {
					return e
				}
				groups[key] = a
			}
			idx = append(idx, row...)
			pop = append(pop, data...)
		}
		if _, err = replacement.pop.WriteAt(pop, int64(replacement.popEnd)); err != nil {
			return err
		}
		if _, err = replacement.idx.WriteAt(idx, headerSize+int64(tail)*int64(s.row.Width)); err != nil {
			return err
		}
		run := Run{Start: tail, End: tail + uint64(len(idx)/s.row.Width), PopStart: replacement.popEnd, PopEnd: replacement.popEnd + uint64(len(pop)), MinMS: minMS, MaxMS: maxMS, IndexCRC: crc32.Checksum(idx, checksum), PopCRC: crc32.Checksum(pop, checksum), TrieSize: len(s.trie.nodes)}
		if replacement.sum != nil {
			summary := makeSummary(run, groups)
			raw, e := encodeSummary(summary)
			if e != nil {
				return e
			}
			if e = appendRecord(replacement.sum, raw); e != nil {
				return e
			}
			stat, e := replacement.sum.Stat()
			if e != nil {
				return e
			}
			replacement.sumEnd = uint64(stat.Size())
			replacement.summaries = append(replacement.summaries, summary)
		}
		raw, e := encoder.Marshal(Commit{run, replacement.sumEnd})
		if e != nil {
			return e
		}
		if err = appendRecord(replacement.tri, raw); err != nil {
			return err
		}
		replacement.runs = append(replacement.runs, run)
		replacement.popEnd = run.PopEnd
		tail = run.End
	}
	// This generation is invisible until every dependency and directory entry is
	// durable. A crash before publication leaves only reclaimable orphan files.
	for _, f := range []*os.File{replacement.pop, replacement.idx, replacement.sum, replacement.tri} {
		if f != nil {
			if err = f.Sync(); err != nil {
				return err
			}
		}
	}
	if err = replacement.mapIndex(); err != nil {
		return err
	}
	var retired []string
	err = filepath.WalkDir(s.dir, func(path string, entry os.DirEntry, e error) error {
		if e != nil {
			return e
		}
		if entry.IsDir() {
			return nil
		}
		filename := entry.Name()
		if !strings.HasPrefix(filename, oldPrefix+".") {
			return nil
		}
		extension := strings.TrimPrefix(filename, oldPrefix+".")
		if extension == "idx" || extension == "pop" || extension == "tri" || extension == "sum" {
			retired = append(retired, path)
			return nil
		}
		if extension != "365" && !(len(extension) == 3 && strings.ContainsRune("wmy", rune(extension[0]))) {
			return nil
		}
		target := filepath.Join(filepath.Dir(path), prefix+"."+extension)
		src, e := openFile(path, "NUTSAGG5", s.layout.Digest, old.generation, 0)
		if e != nil {
			return e
		}
		defer src.Close()
		var kept [][]byte
		e = records(src, func(raw []byte) error {
			var value rollup
			if e := decodeRollup(raw, &value); e != nil {
				return e
			}
			if value.From >= cutoff.UnixMilli() {
				fixed, err := encodeRollup(value)
				if err != nil {
					return err
				}
				kept = append(kept, fixed)
			}
			return nil
		})
		if e != nil {
			return e
		}
		retired = append(retired, path)
		if len(kept) == 0 {
			return nil
		}
		dst, e := openFile(target, "NUTSAGG5", s.layout.Digest, generation, 0)
		if e != nil {
			return e
		}
		created = append(created, target)
		for _, raw := range kept {
			if e = appendRecord(dst, raw); e != nil {
				dst.Close()
				return e
			}
		}
		e = dst.Sync()
		closeErr := dst.Close()
		if e != nil {
			return e
		}
		if closeErr != nil {
			return closeErr
		}
		return syncDir(filepath.Dir(target))
	})
	if err != nil {
		return err
	}
	if err = syncDir(s.dir); err != nil {
		return err
	}
	catalog := s.catalog
	catalog.Generations = map[string]map[Branch][16]byte{}
	for binding, branches := range s.catalog.Generations {
		copyBranches := map[Branch][16]byte{}
		for b, g := range branches {
			copyBranches[b] = g
		}
		catalog.Generations[binding] = copyBranches
	}
	if catalog.Generations[s.binding] == nil {
		catalog.Generations[s.binding] = map[Branch][16]byte{}
	}
	catalog.Generations[s.binding][branch] = generation
	raw, e := encoder.Marshal(catalog)
	if e != nil {
		return e
	}
	if err = replace(filepath.Join(s.root, "collections.map"), raw); err != nil {
		return err
	}
	published = true
	s.catalog = catalog
	s.branches[branch] = replacement
	if err = old.close(); err != nil {
		return err
	}
	if err = s.indexObjects(replacement); err != nil {
		return err
	}
	if branch == Write && s.objects != nil {
		if err = s.compactObjects(); err != nil {
			return err
		}
	}
	for _, path := range retired {
		if err = os.Remove(path); err != nil {
			return err
		}
	}
	return syncDir(s.dir)
}
func (s *Store) compactObjects() error {
	path := filepath.Join(s.collection, "nuts.idx")
	temp, e := os.CreateTemp(s.collection, ".nuts-index-")
	if e != nil {
		return e
	}
	name := temp.Name()
	temp.Close()
	defer os.Remove(name)
	f, e := openFile(name, "NUTSOBJ5", [32]byte{}, [16]byte{}, 0)
	if e != nil {
		return e
	}
	var kept []postingBatch
	for _, batch := range s.objects.batches {
		if batch.Minor == s.layout.Definition.Nuts.Minor && batch.Generation != s.branches[Write].generation {
			continue
		}
		raw, e := encoder.Marshal(batch)
		if e != nil {
			f.Close()
			return e
		}
		if e = appendRecord(f, raw); e != nil {
			f.Close()
			return e
		}
		kept = append(kept, batch)
	}
	if e = f.Sync(); e != nil {
		f.Close()
		return e
	}
	if e = f.Close(); e != nil {
		return e
	}
	if e = os.Rename(name, path); e != nil {
		return e
	}
	if e = syncDir(s.collection); e != nil {
		return e
	}
	if e = s.objects.file.Close(); e != nil {
		return e
	}
	s.objects.file, e = os.OpenFile(path, os.O_RDWR, 0600)
	if e != nil {
		return e
	}
	s.objects.batches = nil
	s.objects.locations = nil
	s.objects.through = nil
	for _, batch := range kept {
		if e = s.objects.add(batch); e != nil {
			return e
		}
	}
	return nil
}
