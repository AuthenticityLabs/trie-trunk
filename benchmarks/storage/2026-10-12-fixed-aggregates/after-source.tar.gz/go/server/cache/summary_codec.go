package cache

import (
	"fmt"
	"math"
)

// Aggregate encoding v1 keeps the existing file binding and length/CRC commit
// framing. SUM1: magic[4], source-from[8], source-through[8], buckets[4], rows[4].
// Each bucket: UTC start-ms[8], row-count[4], then row-count fixed 42-byte rows.
// AGG1 rollup: magic[4], from-ms[8], to-ms[8], row-count[4], then fixed rows.
// Rows: REF16[2], count[8], duration-count[8], sum[8], min[8], max[8].
// All integers are little endian. Metrics are the definition's currently
// supported aggregate set, not mandatory fields on arbitrary collections.
const aggregateRowSize = 42
const summaryHeaderSize = 28
const bucketHeaderSize = 12
const rollupHeaderSize = 24

func validAggregate(a Aggregate) bool {
	if a.Count == 0 || a.DurationCount > a.Count {
		return false
	}
	if a.DurationCount == 0 {
		return a.Sum == 0 && a.Min == 0 && a.Max == 0
	}
	return a.Min <= a.Max && a.Max <= a.Sum && a.Min <= a.Sum/a.DurationCount &&
		(a.Sum/a.DurationCount < a.Max || a.Sum/a.DurationCount == a.Max && a.Sum%a.DurationCount == 0)
}
func putAggregate(dst []byte, g Group) {
	order.PutUint16(dst, g.Reference)
	order.PutUint64(dst[2:], g.Aggregate.Count)
	order.PutUint64(dst[10:], g.Aggregate.DurationCount)
	order.PutUint64(dst[18:], g.Aggregate.Sum)
	order.PutUint64(dst[26:], g.Aggregate.Min)
	order.PutUint64(dst[34:], g.Aggregate.Max)
}
func getAggregate(raw []byte, period int64) Group {
	return Group{period, order.Uint16(raw), Aggregate{order.Uint64(raw[2:]), order.Uint64(raw[10:]), order.Uint64(raw[18:]), order.Uint64(raw[26:]), order.Uint64(raw[34:])}}
}
func validateSummary(s Summary) (int, error) {
	if s.Through <= s.From || len(s.Groups) == 0 {
		return 0, fmt.Errorf("invalid summary source range")
	}
	var count uint64
	buckets := 0
	for i, g := range s.Groups {
		if g.Period < 0 || g.Period%300000 != 0 || !validAggregate(g.Aggregate) || math.MaxUint64-count < g.Aggregate.Count {
			return 0, fmt.Errorf("invalid summary aggregate")
		}
		if i == 0 || g.Period != s.Groups[i-1].Period {
			if i > 0 && g.Period < s.Groups[i-1].Period {
				return 0, fmt.Errorf("unordered summary buckets")
			}
			buckets++
		} else if g.Reference <= s.Groups[i-1].Reference {
			return 0, fmt.Errorf("unordered summary references")
		}
		count += g.Aggregate.Count
	}
	if count != s.Through-s.From {
		return 0, fmt.Errorf("summary count/source mismatch")
	}
	return buckets, nil
}
func encodeSummary(s Summary) ([]byte, error) {
	buckets, e := validateSummary(s)
	if e != nil {
		return nil, e
	}
	if len(s.Groups) > (MaxFrame-summaryHeaderSize-buckets*bucketHeaderSize)/aggregateRowSize {
		return nil, fmt.Errorf("summary too large")
	}
	raw := make([]byte, summaryHeaderSize+buckets*bucketHeaderSize+len(s.Groups)*aggregateRowSize)
	copy(raw, "SUM1")
	order.PutUint64(raw[4:], s.From)
	order.PutUint64(raw[12:], s.Through)
	order.PutUint32(raw[20:], uint32(buckets))
	order.PutUint32(raw[24:], uint32(len(s.Groups)))
	at := summaryHeaderSize
	for i := 0; i < len(s.Groups); {
		end := i + 1
		for end < len(s.Groups) && s.Groups[end].Period == s.Groups[i].Period {
			end++
		}
		order.PutUint64(raw[at:], uint64(s.Groups[i].Period))
		order.PutUint32(raw[at+8:], uint32(end-i))
		at += bucketHeaderSize
		for ; i < end; i++ {
			putAggregate(raw[at:], s.Groups[i])
			at += aggregateRowSize
		}
	}
	return raw, nil
}
func decodeSummary(raw []byte, s *Summary) error {
	// Earlier prototype CBOR records can coexist with new fixed records. A magic
	// tag cannot be mistaken for a CBOR map; unknown fixed versions fail closed.
	if len(raw) > 0 && raw[0]>>5 == 5 {
		*s = Summary{}
		if e := decoder.Unmarshal(raw, s); e != nil {
			return e
		}
		_, e := validateSummary(*s)
		return e
	}
	if len(raw) < summaryHeaderSize || len(raw) > MaxFrame || string(raw[:4]) != "SUM1" {
		return fmt.Errorf("invalid summary encoding")
	}
	buckets, count := uint64(order.Uint32(raw[20:])), uint64(order.Uint32(raw[24:]))
	if buckets == 0 || count < buckets || uint64(summaryHeaderSize)+buckets*bucketHeaderSize+count*aggregateRowSize != uint64(len(raw)) {
		return fmt.Errorf("invalid summary size")
	}
	out := Summary{From: order.Uint64(raw[4:]), Through: order.Uint64(raw[12:]), Groups: make([]Group, 0, int(count))}
	at := summaryHeaderSize
	for i := uint64(0); i < buckets; i++ {
		if len(raw)-at < bucketHeaderSize {
			return fmt.Errorf("short bucket header")
		}
		period, n := int64(order.Uint64(raw[at:])), uint64(order.Uint32(raw[at+8:]))
		at += bucketHeaderSize
		if n == 0 || n > count-uint64(len(out.Groups)) || n > uint64((len(raw)-at)/aggregateRowSize) {
			return fmt.Errorf("invalid bucket rows")
		}
		if len(out.Groups) > 0 && period <= out.Groups[len(out.Groups)-1].Period {
			return fmt.Errorf("duplicate or unordered bucket")
		}
		for j := uint64(0); j < n; j++ {
			out.Groups = append(out.Groups, getAggregate(raw[at:], period))
			at += aggregateRowSize
		}
	}
	if at != len(raw) || uint64(len(out.Groups)) != count {
		return fmt.Errorf("summary boundary mismatch")
	}
	if _, e := validateSummary(out); e != nil {
		return e
	}
	*s = out
	return nil
}
func validateRollup(r rollup) error {
	if r.From >= r.To {
		return fmt.Errorf("invalid aggregate period")
	}
	for i, g := range r.Groups {
		if g.Period != r.From || !validAggregate(g.Aggregate) || i > 0 && g.Reference <= r.Groups[i-1].Reference {
			return fmt.Errorf("invalid rollup group")
		}
	}
	return nil
}
func encodeRollup(r rollup) ([]byte, error) {
	if e := validateRollup(r); e != nil {
		return nil, e
	}
	if len(r.Groups) > (MaxFrame-rollupHeaderSize)/aggregateRowSize {
		return nil, fmt.Errorf("rollup too large")
	}
	raw := make([]byte, rollupHeaderSize+len(r.Groups)*aggregateRowSize)
	copy(raw, "AGG1")
	order.PutUint64(raw[4:], uint64(r.From))
	order.PutUint64(raw[12:], uint64(r.To))
	order.PutUint32(raw[20:], uint32(len(r.Groups)))
	for i, g := range r.Groups {
		putAggregate(raw[rollupHeaderSize+i*aggregateRowSize:], g)
	}
	return raw, nil
}
func decodeRollup(raw []byte, r *rollup) error {
	if len(raw) > 0 && raw[0]>>5 == 5 {
		*r = rollup{}
		if e := decoder.Unmarshal(raw, r); e != nil {
			return e
		}
		return validateRollup(*r)
	}
	if len(raw) < rollupHeaderSize || len(raw) > MaxFrame || string(raw[:4]) != "AGG1" {
		return fmt.Errorf("invalid rollup encoding")
	}
	count := uint64(order.Uint32(raw[20:]))
	if uint64(rollupHeaderSize)+count*aggregateRowSize != uint64(len(raw)) {
		return fmt.Errorf("invalid rollup size")
	}
	out := rollup{From: int64(order.Uint64(raw[4:])), To: int64(order.Uint64(raw[12:])), Groups: make([]Group, int(count))}
	for i := range out.Groups {
		out.Groups[i] = getAggregate(raw[rollupHeaderSize+i*aggregateRowSize:], out.From)
	}
	if e := validateRollup(out); e != nil {
		return e
	}
	*r = out
	return nil
}
