package cache

import (
	"bytes"
	"os"
	"path/filepath"
	"reflect"
	"testing"
	"time"
)

func aggregateFixture() Summary {
	return Summary{From: 4, Through: 10, Groups: []Group{
		{0, 0, Aggregate{Count: 2}},
		{0, 7, Aggregate{Count: 3, DurationCount: 2, Sum: 10, Min: 4, Max: 6}},
		{300000, 2, Aggregate{Count: 1, DurationCount: 1}},
	}}
}
func TestFixedSummaryLayoutAndLegacy(t *testing.T) {
	s := aggregateFixture()
	raw, e := encodeSummary(s)
	if e != nil {
		t.Fatal(e)
	}
	if len(raw) != 28+2*12+3*42 || string(raw[:4]) != "SUM1" {
		t.Fatalf("wrong layout %d", len(raw))
	}
	if order.Uint32(raw[20:]) != 2 || order.Uint32(raw[24:]) != 3 || order.Uint32(raw[36:]) != 2 {
		t.Fatal("wrong bucket counts")
	}
	second := 28 + 12 + 2*42
	if order.Uint64(raw[second:]) != 300000 || order.Uint32(raw[second+8:]) != 1 {
		t.Fatal("wrong second bucket position")
	}
	for _, legacy := range []bool{false, true} {
		input := raw
		if legacy {
			input, e = encoder.Marshal(s)
			if e != nil {
				t.Fatal(e)
			}
		}
		var decoded Summary
		if e = decodeSummary(input, &decoded); e != nil {
			t.Fatal(e)
		}
		if !reflect.DeepEqual(decoded, s) {
			t.Fatalf("round trip legacy=%v", legacy)
		}
	}
	for n := 0; n < len(raw); n++ {
		var decoded Summary
		if decodeSummary(raw[:n], &decoded) == nil {
			t.Fatalf("accepted truncation %d", n)
		}
	}
	mutations := map[string]func([]byte){
		"version":              func(b []byte) { b[3] = '2' },
		"count overflow":       func(b []byte) { order.PutUint32(b[24:], ^uint32(0)) },
		"bucket overflow":      func(b []byte) { order.PutUint32(b[36:], ^uint32(0)) },
		"zero bucket":          func(b []byte) { order.PutUint32(b[36:], 0) },
		"duplicate bucket":     func(b []byte) { order.PutUint64(b[second:], 0) },
		"duplicate ref":        func(b []byte) { order.PutUint16(b[40+42:], 0) },
		"unaligned bucket":     func(b []byte) { order.PutUint64(b[28:], 1) },
		"source mismatch":      func(b []byte) { order.PutUint64(b[12:], 11) },
		"zero count":           func(b []byte) { order.PutUint64(b[42:], 0) },
		"duration over count":  func(b []byte) { order.PutUint64(b[40+10:], 3) },
		"sum without duration": func(b []byte) { order.PutUint64(b[40+18:], 1) },
	}
	for name, mutate := range mutations {
		t.Run(name, func(t *testing.T) {
			b := bytes.Clone(raw)
			mutate(b)
			var decoded Summary
			if decodeSummary(b, &decoded) == nil {
				t.Fatal("accepted corrupt aggregate")
			}
		})
	}
	var decoded Summary
	if decodeSummary(append(bytes.Clone(raw), 0), &decoded) == nil {
		t.Fatal("accepted trailing data")
	}
}
func TestFixedRollupLayoutAndLegacy(t *testing.T) {
	r := rollup{From: -3600000, To: 0, Groups: []Group{{-3600000, 1, Aggregate{Count: 2, DurationCount: 1, Sum: 20, Min: 20, Max: 20}}}}
	for _, groups := range [][]Group{r.Groups, {}} {
		r.Groups = groups
		raw, e := encodeRollup(r)
		if e != nil {
			t.Fatal(e)
		}
		if len(raw) != 24+42*len(groups) {
			t.Fatal("rollup stride")
		}
		for _, legacy := range []bool{false, true} {
			input := raw
			if legacy {
				input, e = encoder.Marshal(r)
				if e != nil {
					t.Fatal(e)
				}
			}
			var got rollup
			if e = decodeRollup(input, &got); e != nil {
				t.Fatal(e)
			}
			if !reflect.DeepEqual(got, r) {
				t.Fatalf("rollup differs: %+v %+v", got, r)
			}
		}
		for n := 0; n < len(raw); n++ {
			var got rollup
			if decodeRollup(raw[:n], &got) == nil {
				t.Fatalf("accepted truncation %d", n)
			}
		}
	}
}

func TestMixedAggregateRecoveryAndRollupPublication(t *testing.T) {
	l := testLayout(t, false)
	from := time.Date(2026, 9, 1, 12, 0, 0, 0, time.UTC)
	c := Config{Root: t.TempDir(), Cache: "demo", Tenant: "test", Layout: l, Now: func() time.Time { return from.Add(72 * time.Hour) }}
	s, e := Open(c)
	if e != nil {
		t.Fatal(e)
	}
	if _, e = s.Append(Write, testFrame(t, l, from, 1, false)); e != nil {
		t.Fatal(e)
	}
	if e = s.Flush(); e != nil {
		t.Fatal(e)
	}
	b := s.branches[Write]
	// Turn the first durable batch into the exact pre-change CBOR representation.
	legacy, e := encoder.Marshal(b.summaries[0])
	if e != nil {
		t.Fatal(e)
	}
	if e = b.sum.Truncate(headerSize); e != nil {
		t.Fatal(e)
	}
	if e = appendRecord(b.sum, legacy); e != nil {
		t.Fatal(e)
	}
	b.sumEnd = uint64(headerSize + 8 + len(legacy))
	commit, e := encoder.Marshal(Commit{b.runs[0], b.sumEnd})
	if e != nil {
		t.Fatal(e)
	}
	if e = b.tri.Truncate(headerSize); e != nil {
		t.Fatal(e)
	}
	if e = appendRecord(b.tri, commit); e != nil {
		t.Fatal(e)
	}
	if e = s.Close(); e != nil {
		t.Fatal(e)
	}
	s, e = Open(c)
	if e != nil {
		t.Fatal(e)
	}
	// New fixed rows correct the same historical bucket; no duplicate totals.
	if _, e = s.Append(Write, testFrame(t, l, from.Add(time.Second), 2, true)); e != nil {
		t.Fatal(e)
	}
	if e = s.Close(); e != nil {
		t.Fatal(e)
	}
	s, e = Open(c)
	if e != nil {
		t.Fatal(e)
	}
	defer s.Close()
	groups, e := s.Summaries(Write, from, from.Add(5*time.Minute))
	if e != nil {
		t.Fatal(e)
	}
	var all Aggregate
	for _, g := range groups {
		for _, a := range g {
			if e = all.merge(a); e != nil {
				t.Fatal(e)
			}
		}
	}
	if all.Count != 2 || all.DurationCount != 1 || all.Sum != 11 {
		t.Fatalf("mixed totals %+v", all)
	}
	if e = s.PublishRollup(Write, Daily, from); e != nil {
		t.Fatal(e)
	}
	path, _, _, e := s.rollupPeriod(Write, Daily, from)
	if e != nil {
		t.Fatal(e)
	}
	f, e := os.OpenFile(path, os.O_RDWR, 0600)
	if e != nil {
		t.Fatal(e)
	}
	var value rollup
	if e = records(f, func(raw []byte) error { return decodeRollup(raw, &value) }); e != nil {
		t.Fatal(e)
	}
	raw, e := encoder.Marshal(value)
	if e != nil {
		t.Fatal(e)
	}
	if e = f.Truncate(headerSize); e != nil {
		t.Fatal(e)
	}
	if e = appendRecord(f, raw); e != nil {
		t.Fatal(e)
	}
	f.Close()
	// Publishing an equivalent old CBOR rollup is idempotent, not a conflict.
	if e = s.PublishRollup(Write, Daily, from); e != nil {
		t.Fatal(e)
	}
	if e = s.PublishRollup(Write, Daily, from.AddDate(0, 0, 1)); e != nil {
		t.Fatal(e)
	}
	got, e := s.ReadRollup(Write, Daily, from)
	if e != nil {
		t.Fatal(e)
	}
	if len(got) != len(value.Groups) {
		t.Fatal("mixed rollup read")
	}
	for _, branch := range []Branch{Debug, Trace} {
		if _, e = s.Append(branch, testFrame(t, l, from, 3, false)); e != nil {
			t.Fatal(e)
		}
		if e = s.Flush(); e != nil {
			t.Fatal(e)
		}
		if _, e = os.Stat(filepath.Join(s.dir, branch.Prefix()+".sum")); !os.IsNotExist(e) {
			t.Fatal("unexpected aggregate file")
		}
	}
}
