# Collection-native storage prototype

This is the opt-in format-5 storage core for the
[collections change plan](../store/COLLECTIONS-CHANGE-PLAN.md). It does not switch
the current ingest server, Rust search process, or Snoot to another format.
Existing tap data has not been migrated or deleted.

## Implemented

- Cache ownership, a domain/collection catalog, immutable definition minors,
  and TOML configuration loaded once rather than per event.
- One compiled `nuts.map` containing the PIL definition and its storage binding.
  Full and partial PIL frames enter the writer without JSON/CBOR object expansion.
- Independent `reads`, `writes`, `errors`, `debug`, and `traces` files. There are
  no event aggregations for nuts, debug, or trace.
- Fixed-width rows, explicit live population bounds, REF16 shared prefixes,
  sorted append runs, and year/day navigation reconstructed from committed runs.
  A null range end resolves against the captured committed source tail.
- UUIDv7 event deduplication, conflicting-ID rejection, late run merging,
  checksummed durable commits, torn-tail recovery, and read-only index mappings.
- Optional write-only object postings across definition minors. Lookups use an
  in-memory object directory and follow source row locators into the write index.
  Disabled-index queries can reject indexed identities before loading population.
- Durable object/scope invalidation tokens independent of retained error payloads.
  A refresh checks its original token; it cannot clear newer uncertainty or
  validate another client's older copy.
- Five-minute durable accumulators, a 15-minute finalization delay, late deltas,
  and explicit day/week/month/year publication. Sparse events without duration
  increment event count without inventing a duration sample. Re-publishing a
  changed closed rollup reports a conflict, as in the existing publication API.
- Separate rolling 30-day shared-trie usage statistics, split by branch.
- Native collection planning and chunk delivery at the Go API: complete daily
  indexes, lazy population, coverage subtraction, known-empty manifests, source
  generations, and byte extents for packed client storage.
- Explicit retention rewrites. Replacement files are synced before an atomic
  catalog switch; object locators are rebuilt and old files are then removed.
  `nuts.state` remains valid after error payloads expire.

## Files

```text
caches/<cache>/
  .writer.lock
  collections.cfg
  collections.map
  collections.tri
  <domain>/<collection>.v<major>/
    nuts.idx                     optional committed-write history
    nuts.state                   durable uncertainty tokens
    <minor>/
      nuts.map
      nuts.tri
      nuts.stats
      reads.idx / .pop / .tri / .sum
      writes.idx / .pop / .tri / .sum
      errors.idx / .pop / .tri / .sum
      debug.idx / .pop / .tri
      traces.idx / .pop / .tri
      writes.yYY                 published yearly rollups
      <yyyy>/writes.365 / writes.mMM / writes.wWW
```

Other aggregate-capable branches use the same rollup suffixes. Branch files
are created on demand. A retained replacement uses a catalog-selected name such
as `writes.g<generation>.idx`; its source row namespace changes. A package is an
interval inventory, not another physical file or saved collection ID.

## Row and population contract

Each binary data file has a 64-byte header: 8-byte kind, 32-byte definition digest,
16-byte generation, 4-byte row width, and 4-byte format version. Numeric header,
row, and PIL primitive values are little endian; UUID bytes retain standard UUID
ordering, including the leading six timestamp bytes.

The index row is:

```text
event_id:16 | [object slot] | [revision slot] | flags:2 | REF16:2 | start:8 | end:8
```

The flags preserve each identity's ABSENT/NULL/DIRECT/OFFSET state. Fixed-width
identities occupy their declared width. A variable STRING/BYTES identity occupies
16 bytes containing its exact population byte offset and length; it is not
truncated or treated as a collision-free hash. The benchmark's two U64 identities
produce a **52-byte live row**, not a 24/26/28-byte event-only row.

The population is a PIL projection with indexed direct identities and shared
prefix fields omitted. The original field-state mask remains in population.
`Search` reconstructs a standalone PIL frame from borrowed primitive slots for
CLI output. `Collect` transfers native index/population ranges and shared nodes
without that reconstruction. Field strings are resolved through the definition
only when needed by a consumer.

REF16 zero denotes no shared prefix. There are at most 65,535 non-root nodes;
exhaustion leaves remaining values literal. A missing root produces no reference.
Shared references never turn missing PATCH fields into assignments.

Commit records live in each branch's `.tri`, outside the fixed row area. They
bind row and population bounds, checksums, shared-node availability, and summary
watermarks. Incomplete final journal records are discarded; corruption in a
complete committed record fails recovery.

## Aggregate rows

New accumulator records use `SUM1` fixed positional encoding inside the existing
length/CRC framing. The source row range and bucket/row counts appear once per
committed batch (28 bytes). Each bucket header stores its absolute epoch start
and row count once (12 bytes), followed by sorted 42-byte entries:

```text
REF16:2 | count:8 | duration-count:8 | sum:8 | min:8 | max:8
```

A row is addressed as `bucket_values_start + row_number * 42`. These are the
currently supported, explicitly configured metrics; collections without those
aggregations do not acquire duration fields. All numeric values are little
endian. Empty duration samples preserve count separately. `AGG1` published
rollups store the period's start/end and row count once (24 bytes), followed by
the same entries. File headers remain 64 bytes and each committed record has an
8-byte length/CRC header. No additional files or definition versions are needed.

Existing prototype CBOR summaries and rollups remain readable, including files
with both encodings. New writes use fixed rows; retention rewrites retained
rollups in fixed form. Older executables cannot read the new tagged records.
Source watermarks still prevent applying a delta twice. Late batches can append
another group for an existing bucket; fixed rows do not change finalization or
closed-rollup conflict handling. Warm `Summaries` queries still merge decoded
in-memory groups; the format change primarily improves persistence and reload.

## Use

Build the CLI without replacing the running executable:

```sh
cd go
go build -o /tmp/trunk-cache ./cmd/trunk
```

Register a unified definition supplied as JSON or its compiled CBOR `nuts.map`:

```sh
/tmp/trunk-cache cache init --dir ./caches --cache demo --tenant authenticity \
  --definition definition.json --object-index
```

The JSON form follows `Definition` in `definition.go`: ordered PIL fields plus
`nuts` identity, roles, shared path, timezone, and declared aggregations. Object
and revision identity types remain compatible across minors of one major.

Ingest/search use concatenated PIL frames whose lengths are derived from their
definition and cumulative offsets:

```sh
/tmp/trunk-cache cache ingest --dir ./caches --cache demo --tenant authenticity \
  --definition definition.json --branch write < frames.pil
/tmp/trunk-cache cache search --dir ./caches --cache demo --tenant authenticity \
  --definition definition.json --branch write \
  --from 2026-09-01T00:00:00Z --to 2026-10-01T00:00:00Z > selected.pil
```

`cache verify` opens and verifies committed storage. `cache prune` explicitly
applies the configured retention to the bound definition minor. There are no
implicit retention durations in the generated configuration. Definitions/tries
are kept while events may refer to them.

## Validation and remaining integration

Tests cover late/overlapping runs, sparse and nullable fields, fixed/variable IDs,
duplicate/conflicting events, recovery and corruption, REF16 exhaustion, native
gap filling, error invalidation, aggregates, retention, and CLI round trips.
`pil/examples/cache_interop.rs` checks emitted frames with the existing Rust
codec using the same `nuts.map`; the normal WASM build uses that codec.

This is still a **prototype**, with these rollout gates remaining:

- One open `Store` binds one definition and holds the cache writer lease. A
  multi-collection server coordinator and concurrent snapshot readers are needed
  before replacing the existing running services.
- Native `Collect` is a Go API, not yet the negotiated HTTP stream or the browser
  SharedWorker/OPFS implementation. The existing HTTP protocol is unchanged.
- `ObjectLocations` spans minors; `History` resolves frames in the current minor.
  Recovery/backfill currently opens the bound minor. Cross-minor recovery/replay
  orchestration and source-specific revision ordering remain
  application work. Opaque revisions are not assumed causally sortable.
- The map is compiled/cached CBOR metadata, not a finalized section-addressable
  map format or an OpenAPI application-definition compiler.
- Statistics describe shared-prefix usage/cardinality; literal overflow values
  are counted as unshared rather than claimed as a complete field distribution.
- An invalidation snapshot can be replicated, but reconnect protocol paging,
  persistent state-journal compaction, and client reconciliation are unfinished.
- Offline source migration, definition garbage collection, client generation
  invalidation, orphan-generation reclamation, and the browser's packed extent
  commits require integration tests.
- The mapping relies on the OS page cache. It does not implement the planned
  explicit 24-hour resident-memory budget or establish production concurrency
  and physical-disk-cold performance.

See the [measured comparison](../../../benchmarks/storage/2026-10-12/REPORT.md).
The prototype improves several timings in these fixtures but **increases size**;
the reports separate the legacy Rust/IPC path from the native Go API path.

See the [fixed aggregate and same-reader codec measurements](../../../benchmarks/storage/2026-10-12-fixed-aggregates/REPORT.md) for the controlled follow-up.
