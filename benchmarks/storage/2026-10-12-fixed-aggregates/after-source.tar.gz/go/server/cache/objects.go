package cache

import (
	"bytes"
	"context"
	"crypto/rand"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"time"
)

type Posting struct {
	Row      uint64 `cbor:"0,keyasint"`
	Object   []byte `cbor:"1,keyasint"`
	Revision Value  `cbor:"2,keyasint"`
}
type postingBatch struct {
	Minor         uint32   `cbor:"0,keyasint"`
	Generation    [16]byte `cbor:"1,keyasint"`
	From, Through uint64
	Entries       []Posting
}
type ObjectLocation struct {
	Minor      uint32
	Generation [16]byte
	Row        uint64
	Revision   Value
}
type objectIndex struct {
	file      *os.File
	batches   []postingBatch
	locations map[string][]postingRef
	through   map[objectBinding]uint64
}
type postingRef struct{ Batch, Entry int }
type objectBinding struct {
	Minor      uint32
	Generation [16]byte
}

func (i *objectIndex) add(p postingBatch) error {
	if i.locations == nil {
		i.locations = map[string][]postingRef{}
		i.through = map[objectBinding]uint64{}
	}
	key := objectBinding{p.Minor, p.Generation}
	if p.From != i.through[key] || p.Through <= p.From {
		return fmt.Errorf("invalid object watermark")
	}
	var prior uint64
	for n, entry := range p.Entries {
		if entry.Row < p.From || entry.Row >= p.Through || n > 0 && entry.Row <= prior {
			return fmt.Errorf("invalid object posting")
		}
		prior = entry.Row
		id := string(entry.Object)
		i.locations[id] = append(i.locations[id], postingRef{len(i.batches), n})
	}
	i.batches = append(i.batches, p)
	i.through[key] = p.Through
	return nil
}

func (s *Store) openObjects() error {
	if !s.config.ObjectIndex {
		return nil
	}
	if s.layout.Object < 0 {
		return fmt.Errorf("object index requires an object identity role")
	}
	f, e := openFile(filepath.Join(s.collection, "nuts.idx"), "NUTSOBJ5", [32]byte{}, [16]byte{}, 0)
	if e != nil {
		return e
	}
	s.objects = &objectIndex{file: f}
	return records(f, func(b []byte) error {
		var p postingBatch
		if e := decoder.Unmarshal(b, &p); e != nil {
			return e
		}
		if p.Through <= p.From {
			return fmt.Errorf("invalid object index watermark")
		}
		return s.objects.add(p)
	})
}

// The optional index is derived. A crash after writes.tri commits but before this
// append is recovered by backfilling the missing source rows, without duplicating
// payloads or accepting an object posting as evidence of a committed write.
func (s *Store) indexObjects(b *branchStore) error {
	if !s.config.ObjectIndex || s.objects == nil || b.branch != Write {
		return nil
	}
	minor := s.layout.Definition.Nuts.Minor
	through := s.objects.through[objectBinding{minor, b.generation}]
	tail := uint64(len(b.rows) / s.row.Width)
	if through > tail {
		return fmt.Errorf("object index ahead of source")
	}
	if through == tail {
		return nil
	}
	for through < tail {
		end := through + 1024
		if end > tail {
			end = tail
		}
		p := postingBatch{Minor: minor, Generation: b.generation, From: through, Through: end}
		for n := through; n < end; n++ {
			row := b.rows[n*uint64(s.row.Width) : (n+1)*uint64(s.row.Width)]
			state := State(row[s.row.Flags] & 3)
			if state == Absent || state == Null {
				continue
			}
			object, e := s.identity(b, row, s.layout.Object, s.row.Object)
			if e != nil {
				return e
			}
			revision := Value{}
			if s.layout.Revision >= 0 {
				revision.State = State(row[s.row.Flags] >> 2 & 3)
				if revision.State >= Direct {
					revision.Bytes, e = s.identity(b, row, s.layout.Revision, s.row.Revision)
					if e != nil {
						return e
					}
				}
			}
			p.Entries = append(p.Entries, Posting{n, append([]byte(nil), object...), revision})
		}
		raw, e := encoder.Marshal(p)
		if e != nil {
			return e
		}
		if e = appendRecord(s.objects.file, raw); e != nil {
			return e
		}
		if e = s.objects.file.Sync(); e != nil {
			return e
		}
		if e = s.objects.add(p); e != nil {
			return e
		}
		through = end
	}
	return nil
}
func (s *Store) identity(b *branchStore, row []byte, field, slot int) ([]byte, error) {
	if w := s.layout.Widths[field]; w > 0 {
		return append([]byte(nil), row[slot:slot+w]...), nil
	}
	start, length := order.Uint64(row[slot:]), order.Uint64(row[slot+8:])
	from, to := order.Uint64(row[s.row.Start:]), order.Uint64(row[s.row.End:])
	if start < from || start > to || length > to-start {
		return nil, fmt.Errorf("invalid identity indirection")
	}
	return readBytes(b.pop, start, start+length)
}

// ObjectLocations spans definition minors, but only committed writes enter the
// index. Ordering is event-time order in History; opaque revisions aren't assumed
// sortable. Consumers can stop at an exact source revision after resolving rows.
func (s *Store) ObjectLocations(id Value) ([]ObjectLocation, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if e := s.check(); e != nil {
		return nil, e
	}
	if !s.config.ObjectIndex || s.objects == nil {
		return nil, fmt.Errorf("object index disabled")
	}
	if e := s.validateObject(id); e != nil {
		return nil, e
	}
	if b := s.branches[Write]; b != nil {
		if e := s.flush(b); e != nil {
			return nil, s.fail(e)
		}
		if e := s.indexObjects(b); e != nil {
			return nil, s.fail(e)
		}
	}
	var out []ObjectLocation
	for _, ref := range s.objects.locations[string(id.Bytes)] {
		batch := s.objects.batches[ref.Batch]
		n := s.layout.Definition.Nuts
		binding := fmt.Sprintf("%s/%s.v%d/%d", n.Domain, n.Collection, n.Major, batch.Minor)
		if active, ok := s.catalog.Generations[binding][Write]; ok && active != batch.Generation {
			continue
		}
		if batch.Minor == s.layout.Definition.Nuts.Minor {
			if b := s.branches[Write]; b == nil || batch.Generation != b.generation {
				continue
			}
		}
		for _, p := range batch.Entries[ref.Entry : ref.Entry+1] {
			if bytes.Equal(id.Bytes, p.Object) {
				r := p.Revision
				r.Bytes = append([]byte(nil), r.Bytes...)
				out = append(out, ObjectLocation{batch.Minor, batch.Generation, p.Row, r})
			}
		}
	}
	return out, nil
}

// History uses the current minor's optional postings, or a time scan if disabled.
// Cross-minor callers use ObjectLocations and resolve each immutable source map.
func (s *Store) History(ctx context.Context, id Value, from, to time.Time, visit func(uint64, []byte) error) error {
	s.mu.Lock()
	enabled, role := s.config.ObjectIndex, s.layout.Definition.Nuts.Roles.Object
	s.mu.Unlock()
	if !enabled {
		return s.Search(ctx, Query{Branch: Write, From: from, To: to, Equals: map[string]Value{role: id}}, visit)
	}
	locations, e := s.ObjectLocations(id)
	if e != nil {
		return e
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if e = s.check(); e != nil {
		return e
	}
	b := s.branches[Write]
	if b == nil {
		return nil
	}
	var rows []uint64
	for _, location := range locations {
		if location.Minor == s.layout.Definition.Nuts.Minor && location.Generation == b.generation {
			if location.Row >= uint64(len(b.rows)/s.row.Width) {
				return fmt.Errorf("object locator beyond source")
			}
			row := b.rows[location.Row*uint64(s.row.Width):]
			ms := eventTime(row)
			if ms >= from.UnixMilli() && ms < to.UnixMilli() {
				rows = append(rows, location.Row)
			}
		}
	}
	sort.Slice(rows, func(i, j int) bool {
		a, c := rows[i]*uint64(s.row.Width), rows[j]*uint64(s.row.Width)
		return bytes.Compare(b.rows[a:a+16], b.rows[c:c+16]) < 0
	})
	var frame []byte
	for _, n := range rows {
		if e = ctx.Err(); e != nil {
			return e
		}
		frame, e = s.frame(b, b.rows[n*uint64(s.row.Width):(n+1)*uint64(s.row.Width)], frame)
		if e != nil {
			return e
		}
		if e = visit(n, frame); e != nil {
			return e
		}
	}
	return nil
}

type StateToken struct {
	Epoch              [16]byte
	Collection, Object uint64
}
type invalidation struct {
	Sequence   uint64
	Objects    [][]byte
	Collection bool
}
type objectState struct {
	file                 *os.File
	epoch                [16]byte
	sequence, collection uint64
	objects              map[string]uint64
}

func (s *Store) openState() error {
	path := filepath.Join(s.collection, "nuts.state")
	var epoch [16]byte
	f, e := os.Open(path)
	if e == nil {
		var h [headerSize]byte
		_, e = f.Read(h[:])
		f.Close()
		if e != nil {
			return e
		}
		copy(epoch[:], h[40:56])
	} else if os.IsNotExist(e) {
		if _, e = rand.Read(epoch[:]); e != nil {
			return e
		}
	} else {
		return e
	}
	f, e = openFile(path, "NUTSSTA5", [32]byte{}, epoch, 0)
	if e != nil {
		return e
	}
	s.state = &objectState{file: f, epoch: epoch, objects: map[string]uint64{}}
	return records(f, func(raw []byte) error {
		var v invalidation
		if e := decoder.Unmarshal(raw, &v); e != nil {
			return e
		}
		if v.Sequence != s.state.sequence+1 {
			return fmt.Errorf("invalidation sequence gap")
		}
		s.state.sequence = v.Sequence
		if v.Collection {
			s.state.collection = v.Sequence
		} else {
			for _, object := range v.Objects {
				s.state.objects[string(object)] = v.Sequence
			}
		}
		return nil
	})
}
func (s *Store) invalidate(objects [][]byte, collection bool) error {
	st := s.state
	if st.sequence == ^uint64(0) {
		return fmt.Errorf("invalidation sequence exhausted")
	}
	v := invalidation{Sequence: st.sequence + 1, Objects: objects, Collection: collection}
	raw, e := encoder.Marshal(v)
	if e != nil {
		return e
	}
	if e = appendRecord(st.file, raw); e != nil {
		return e
	}
	if e = st.file.Sync(); e != nil {
		return e
	}
	st.sequence = v.Sequence
	if collection {
		st.collection = v.Sequence
	} else {
		for _, object := range objects {
			st.objects[string(object)] = v.Sequence
		}
	}
	return nil
}
func (s *Store) token(id Value) StateToken {
	return StateToken{Epoch: s.state.epoch, Collection: s.state.collection, Object: s.state.objects[string(id.Bytes)]}
}

func (s *Store) validateObject(id Value) error {
	if s.layout.Object < 0 {
		return fmt.Errorf("no object identity declared")
	}
	w := s.layout.Widths[s.layout.Object]
	if w > 0 {
		if id.State != Direct || len(id.Bytes) != w {
			return fmt.Errorf("object identity type mismatch")
		}
	} else if id.State != Offset {
		return fmt.Errorf("object identity type mismatch")
	}
	return nil
}
func (s *Store) Token(id Value) (StateToken, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if e := s.check(); e != nil {
		return StateToken{}, e
	}
	if e := s.validateObject(id); e != nil {
		return StateToken{}, e
	}
	return s.token(id), nil
}

// StillCurrent guards a client's origin refresh. It does not clear state shared
// with other clients, and a concurrent newer invalidation makes it return false.
func (s *Store) StillCurrent(id Value, observed StateToken) (bool, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if e := s.check(); e != nil {
		return false, e
	}
	if e := s.validateObject(id); e != nil {
		return false, e
	}
	return observed == s.token(id), nil
}
