package cache

import (
	"bufio"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"os"
	"runtime"
	"testing"
	"time"
	"trie-trunk/go/codec"
)

// These adapters intentionally use the existing compact CBOR implementation.
// Field IDs and dictionary ordinals remain numeric. No expanded JSON is built.
// This is a benchmark population adapter, not a second production file format.
func fixtureCBOR(l *Layout, values []Value) (codec.Record, error) {
	r := codec.Record{}
	for i, v := range values {
		if v.State == Absent {
			continue
		}
		var value any
		switch v.State {
		case Null:
			value = nil
		case Direct:
			if l.Definition.Fields[i].Type == "UUID" {
				value = v.Bytes
			} else {
				value = unsigned(v.Bytes)
			}
		case Offset:
			if l.Definition.Fields[i].Type == "STRING" {
				value = string(v.Bytes)
			} else {
				return nil, fmt.Errorf("unsupported benchmark variable type")
			}
		}
		r[codec.Key(i)] = value
	}
	return r, nil
}
func scanFixtureCBOR(l *Layout, raw []byte, f *Frame) error {
	r, e := codec.Decode(raw, codec.CBOR)
	if e != nil {
		return e
	}
	f.Values = make([]Value, len(l.Widths))
	for key, v := range r {
		i := int(key)
		if i >= len(f.Values) {
			return fmt.Errorf("unknown benchmark field")
		}
		switch v := v.(type) {
		case nil:
			f.Values[i] = Value{State: Null}
		case uint64:
			w := l.Widths[i]
			if w <= 0 || w > 8 {
				return fmt.Errorf("invalid integer width")
			}
			if w < 8 && v >= uint64(1)<<uint(w*8) {
				return fmt.Errorf("CBOR integer overflow")
			}
			if len(l.Definition.Fields[i].Values) > 0 && v >= uint64(len(l.Definition.Fields[i].Values)) {
				return fmt.Errorf("invalid CBOR dictionary reference")
			}
			f.Values[i] = Uint(v, w)
		case string:
			f.Values[i] = Text(v)
		case []byte:
			f.Values[i] = Value{Direct, v}
		default:
			return fmt.Errorf("unsupported benchmark scalar %T", v)
		}
	}
	return nil
}
func (s *Store) fixtureCBORFrame(b *branchStore, row, dst []byte) ([]byte, error) {
	raw, e := readBytes(b.pop, order.Uint64(row[s.row.Start:]), order.Uint64(row[s.row.End:]))
	if e != nil {
		return nil, e
	}
	var f Frame
	if e = scanFixtureCBOR(s.layout, raw, &f); e != nil {
		return nil, e
	}
	return s.expandFrame(row, &f, dst)
}

func TestMeasurePopulationCodecs(t *testing.T) {
	n := measurementSize(t)
	sparse := os.Getenv("TRUNK_MEASURE_SHAPE") == "sparse"
	l, frames, from, to, hash := measurementFixture(t, n, sparse)
	c := Config{Root: t.TempDir(), Cache: "bench", Tenant: "measure", Layout: l, Now: func() time.Time { return to.Add(time.Hour) }}
	s, e := Open(c)
	if e != nil {
		t.Fatal(e)
	}
	defer s.Close()
	for _, f := range frames {
		if _, e = s.Append(Write, f); e != nil {
			t.Fatal(e)
		}
	}
	if e = s.Flush(); e != nil {
		t.Fatal(e)
	}
	original := s.branches[Write]
	alt := *original
	alt.rows = append([]byte(nil), original.rows...)
	alt.pop, e = os.CreateTemp(t.TempDir(), "cbor-pop-")
	if e != nil {
		t.Fatal(e)
	}
	defer alt.pop.Close()
	writer := bufio.NewWriterSize(alt.pop, 1<<20)
	if _, e = writer.Write(make([]byte, headerSize)); e != nil {
		t.Fatal(e)
	}
	at := uint64(headerSize)
	// Prepare one representative committed batch for encode/decode measurements;
	// the full population comparison below uses every record in both files.
	var pilBatch, cborBatch [][]byte
	var valueBatch [][]Value
	var recordBatch []codec.Record
	for offset := 0; offset < len(alt.rows); offset += s.row.Width {
		row := alt.rows[offset : offset+s.row.Width]
		raw, e := readBytes(original.pop, order.Uint64(row[s.row.Start:]), order.Uint64(row[s.row.End:]))
		if e != nil {
			t.Fatal(e)
		}
		var f Frame
		if e = l.Scan(raw, &f); e != nil {
			t.Fatal(e)
		}
		record, e := fixtureCBOR(l, f.Values)
		if e != nil {
			t.Fatal(e)
		}
		encoded, e := codec.MarshalCompact(record, codec.CBOR)
		if e != nil {
			t.Fatal(e)
		}
		if len(pilBatch) < 1024 {
			pilBatch = append(pilBatch, raw)
			cborBatch = append(cborBatch, encoded)
			valueBatch = append(valueBatch, f.Values)
			recordBatch = append(recordBatch, record)
		}
		order.PutUint64(row[s.row.Start:], at)
		if _, e = writer.Write(encoded); e != nil {
			t.Fatal(e)
		}
		at += uint64(len(encoded))
		order.PutUint64(row[s.row.End:], at)
	}
	if e = writer.Flush(); e != nil {
		t.Fatal(e)
	}
	if e = alt.pop.Sync(); e != nil {
		t.Fatal(e)
	}
	popStat, e := original.pop.Stat()
	if e != nil {
		t.Fatal(e)
	}
	results := map[string]map[string]timing{}
	hashes := map[string]string{}
	matched := map[string]int{}
	queries := []struct {
		name  string
		query Query
	}{
		{"all", Query{Branch: Write, From: from, To: to}},
		{"day", Query{Branch: Write, From: from.AddDate(0, 0, 15), To: from.AddDate(0, 0, 16)}},
		{"three_hours", Query{Branch: Write, From: from.AddDate(0, 0, 15).Add(9 * time.Hour), To: from.AddDate(0, 0, 15).Add(12 * time.Hour)}},
		{"state", Query{Branch: Write, From: from, To: to, Equals: map[string]Value{"state": Text("canceled")}}},
	}
	defer func() { s.branches[Write] = original }()
	for _, q := range queries {
		var expected string
		modes := []string{"cbor", "pil"}
		if n == 500000 {
			modes = []string{"pil", "cbor"}
		}
		runs := map[string]func() error{}
		for _, mode := range modes {
			mode := mode
			run := func(visit func(uint64, []byte) error) error {
				b, reader := original, s.frame
				if mode == "cbor" {
					b, reader = &alt, s.fixtureCBORFrame
				}
				s.branches[Write] = b
				return s.search(context.Background(), q.query, visit, reader)
			}
			digest := sha256.New()
			count := 0
			if e = run(func(_ uint64, b []byte) error { count++; digest.Write(b); return nil }); e != nil {
				t.Fatal(e)
			}
			got := hex.EncodeToString(digest.Sum(nil))
			if expected != "" && expected != got {
				t.Fatal("codec output differs")
			}
			expected = got
			hashes[q.name] = got
			matched[q.name] = count
			runs[mode] = func() error {
				seen := 0
				err := run(func(uint64, []byte) error { seen++; return nil })
				if err != nil {
					return err
				}
				if seen != count {
					return fmt.Errorf("result count changed")
				}
				return nil
			}
		}
		// Interleave samples to avoid attributing sustained warmup/thermal drift to
		// whichever codec happened to run first. Warmup and validation are untimed.
		samples := map[string]timing{"cbor": {}, "pil": {}}
		for i := 0; i < 9; i++ {
			for _, mode := range modes {
				start := time.Now()
				if e = runs[mode](); e != nil {
					t.Fatal(e)
				}
				v := samples[mode]
				v.Samples = append(v.Samples, time.Since(start).Nanoseconds())
				samples[mode] = v
			}
			modes[0], modes[1] = modes[1], modes[0]
		}
		for mode, v := range samples {
			samples[mode] = timingSamples(v.Samples)
		}
		results[q.name] = samples
	}
	s.branches[Write] = original
	codecTimings := map[string]timing{}
	codecTimings["cbor_encode_1024"] = timed(t, 21, func() error {
		for _, v := range recordBatch {
			if _, e := codec.MarshalCompact(v, codec.CBOR); e != nil {
				return e
			}
		}
		return nil
	})
	codecTimings["pil_encode_1024"] = timed(t, 21, func() error {
		for _, v := range valueBatch {
			if _, e := l.Encode(nil, v); e != nil {
				return e
			}
		}
		return nil
	})
	codecTimings["cbor_decode_1024"] = timed(t, 21, func() error {
		for _, v := range cborBatch {
			var f Frame
			if e := scanFixtureCBOR(l, v, &f); e != nil {
				return e
			}
		}
		return nil
	})
	codecTimings["pil_decode_1024"] = timed(t, 21, func() error {
		for _, v := range pilBatch {
			var f Frame
			if e := l.Scan(v, &f); e != nil {
				return e
			}
		}
		return nil
	})
	saveMeasurement(t, map[string]any{"events": n, "sparse": sparse, "fixture_sha256": hash, "go": runtime.Version(), "platform": runtime.GOOS + "/" + runtime.GOARCH,
		"population_bytes": map[string]int64{"cbor": int64(at) - headerSize, "pil": popStat.Size() - headerSize}, "index_bytes_each": len(original.rows), "query": results, "result_hashes": hashes, "matched_events": matched, "codec_batch_events": len(pilBatch), "codec": codecTimings})
}

func TestPopulationCodecEquivalence(t *testing.T) {
	l, frames, from, to, _ := measurementFixture(t, 12, false)
	// Include NULL and empty text as well as absent PATCH fields.
	for i := 0; i < 2; i++ {
		var f Frame
		if e := l.Scan(frames[i], &f); e != nil {
			t.Fatal(e)
		}
		if i == 0 {
			f.Values[7] = Value{State: Null}
		} else {
			f.Values[7] = Text("")
			f.Values[3] = Value{}
		}
		var e error
		frames[i], e = l.Encode(nil, f.Values)
		if e != nil {
			t.Fatal(e)
		}
	}
	_, sparse, _, _, _ := measurementFixture(t, 12, true)
	for _, set := range [][][]byte{frames, sparse} {
		s, e := Open(Config{Root: t.TempDir(), Cache: "bench", Tenant: "test", Layout: l, Now: func() time.Time { return to.Add(time.Hour) }})
		if e != nil {
			t.Fatal(e)
		}
		for _, raw := range set {
			if _, e = s.Append(Write, raw); e != nil {
				t.Fatal(e)
			}
		}
		if e = s.Flush(); e != nil {
			t.Fatal(e)
		}
		b := s.branches[Write]
		for at := 0; at < len(b.rows); at += s.row.Width {
			row := b.rows[at : at+s.row.Width]
			raw, e := readBytes(b.pop, order.Uint64(row[s.row.Start:]), order.Uint64(row[s.row.End:]))
			if e != nil {
				t.Fatal(e)
			}
			var f Frame
			if e = l.Scan(raw, &f); e != nil {
				t.Fatal(e)
			}
			record, e := fixtureCBOR(l, f.Values)
			if e != nil {
				t.Fatal(e)
			}
			encoded, e := codec.MarshalCompact(record, codec.CBOR)
			if e != nil {
				t.Fatal(e)
			}
			var other Frame
			if e = scanFixtureCBOR(l, encoded, &other); e != nil {
				t.Fatal(e)
			}
			pil, e := s.expandFrame(row, &f, nil)
			if e != nil {
				t.Fatal(e)
			}
			cbor, e := s.expandFrame(row, &other, nil)
			if e != nil {
				t.Fatal(e)
			}
			if string(pil) != string(cbor) {
				t.Fatal("CBOR/PIL expansion differs")
			}
		}
		if len(collect(t, s, Write, from, to)) != 12 {
			t.Fatal("query count")
		}
		if e = s.Close(); e != nil {
			t.Fatal(e)
		}
	}
}
