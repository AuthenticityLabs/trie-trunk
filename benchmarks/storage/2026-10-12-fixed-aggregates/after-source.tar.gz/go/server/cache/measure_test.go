package cache

// Opt-in, reproducible measurements. Normal go test runs only the small
// correctness tests; TRUNK_MEASURE_OUT enables the large fixture runs.
import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"sort"
	"strconv"
	"testing"
	"time"
)

type timing struct {
	Samples []int64 `json:"samples_ns"`
	P50     int64   `json:"p50_ns"`
	P95     int64   `json:"p95_ns"`
}

func timed(t *testing.T, samples int, run func() error) timing {
	t.Helper()
	if e := run(); e != nil {
		t.Fatal(e)
	}
	v := timing{}
	for i := 0; i < samples; i++ {
		start := time.Now()
		if e := run(); e != nil {
			t.Fatal(e)
		}
		v.Samples = append(v.Samples, time.Since(start).Nanoseconds())
	}
	return timingSamples(v.Samples)
}

func timingSamples(samples []int64) timing {
	v := timing{Samples: samples}
	ordered := append([]int64(nil), v.Samples...)
	sort.Slice(ordered, func(i, j int) bool { return ordered[i] < ordered[j] })
	v.P50, v.P95 = ordered[len(ordered)/2], ordered[(len(ordered)*95+99)/100-1]
	return v
}

func measurementSize(t *testing.T) int {
	t.Helper()
	if os.Getenv("TRUNK_MEASURE_OUT") == "" {
		t.Skip("opt-in storage measurement")
	}
	n, e := strconv.Atoi(os.Getenv("TRUNK_MEASURE_EVENTS"))
	if e != nil || n < 1 {
		t.Fatal("TRUNK_MEASURE_EVENTS must be positive")
	}
	return n
}
func saveMeasurement(t *testing.T, v any) {
	t.Helper()
	raw, e := json.MarshalIndent(v, "", "  ")
	if e != nil {
		t.Fatal(e)
	}
	path := os.Getenv("TRUNK_MEASURE_OUT")
	if e = os.MkdirAll(filepath.Dir(path), 0755); e != nil {
		t.Fatal(e)
	}
	if e = os.WriteFile(path, append(raw, '\n'), 0644); e != nil {
		t.Fatal(e)
	}
}

// Twelve fields, including strings, scalars, mapped values and identity roles.
// Sparse events carry the identity envelope and just one or two changed fields.
func measurementFixture(t *testing.T, n int, sparse bool) (*Layout, [][]byte, time.Time, time.Time, string) {
	t.Helper()
	l, e := Compile(Definition{Identity: "payment/transactions", Version: 1 << 20, Fields: []Field{
		{Name: "event_id", Type: "UUID"}, {Name: "id", Type: "U64"}, {Name: "revision_id", Type: "U64"},
		{Name: "duration", Type: "U64"}, {Name: "level", Type: "STRING", Values: []string{"INFO", "ERROR"}},
		{Name: "operation", Type: "STRING", Values: []string{"create", "update", "cancel"}},
		{Name: "state", Type: "STRING", Values: []string{"pending", "authorized", "canceled"}},
		{Name: "message", Type: "STRING"}, {Name: "amount", Type: "U64"}, {Name: "customer_id", Type: "U64"},
		{Name: "instance", Type: "STRING"}, {Name: "attempt", Type: "U32"},
	}, Nuts: Binding{Format: Format, Domain: "payment", Collection: "transactions", Major: 1, Timezone: "UTC",
		Roles: Roles{Event: "event_id", Object: "id", Revision: "revision_id", Duration: "duration"}, Path: []string{"level", "operation", "state"},
		Aggregations: []string{"count", "duration.count", "duration.sum", "duration.min", "duration.max"}}})
	if e != nil {
		t.Fatal(e)
	}
	from := time.Date(2026, 9, 1, 0, 0, 0, 0, time.UTC)
	to := from.AddDate(0, 0, 30)
	frames := make([][]byte, n)
	h := sha256.New()
	for i := range frames {
		ms := from.UnixMilli() + int64(i)*(to.UnixMilli()-from.UnixMilli())/int64(n)
		v := []Value{uuid(ms, uint32(i)), Uint(uint64(i%10000), 8), Uint(uint64(i/10000+1), 8), Uint(uint64(50+i*7919%100000), 8),
			Uint(uint64(i%20/19), 1), Uint(uint64(i%3), 1), Uint(uint64(i%3), 1), Text(fmt.Sprintf("Transaction %d completed", i)),
			Uint(uint64(i%100000), 8), Uint(uint64(i%5000), 8), Text(fmt.Sprintf("payment-%02d", i%12)), Uint(uint64(i%4), 4)}
		if sparse {
			for j := 3; j < len(v); j++ {
				v[j] = Value{}
			}
			v[6] = Uint(uint64(i%3), 1)
			if i%2 == 0 {
				v[8] = Uint(uint64(i%100000), 8)
			}
		}
		frames[i], e = l.Encode(nil, v)
		if e != nil {
			t.Fatal(e)
		}
		h.Write(frames[i])
	}
	return l, frames, from, to, hex.EncodeToString(h.Sum(nil))
}

func TestMeasureAggregateStorage(t *testing.T) {
	n := measurementSize(t)
	l, frames, from, to, hash := measurementFixture(t, n, false)
	config := Config{Root: t.TempDir(), Cache: "bench", Tenant: "measure", Layout: l, Now: func() time.Time { return to.Add(time.Hour) }}
	s, e := Open(config)
	if e != nil {
		t.Fatal(e)
	}
	start := time.Now()
	for _, f := range frames {
		if _, e = s.Append(Write, f); e != nil {
			t.Fatal(e)
		}
	}
	if e = s.Close(); e != nil {
		t.Fatal(e)
	}
	ingest := time.Since(start).Nanoseconds()
	var reopen timing
	reopen = timed(t, 9, func() error {
		var err error
		s, err = Open(config)
		if err != nil {
			return err
		}
		return s.Close()
	})
	s, e = Open(config)
	if e != nil {
		t.Fatal(e)
	}
	defer s.Close()
	b := s.branches[Write]
	stat, e := b.sum.Stat()
	if e != nil {
		t.Fatal(e)
	}
	var rawRecords [][]byte
	if e = records(b.sum, func(raw []byte) error { rawRecords = append(rawRecords, raw); return nil }); e != nil {
		t.Fatal(e)
	}
	var groupCount, eventCount uint64
	for _, summary := range b.summaries {
		for _, g := range summary.Groups {
			groupCount++
			eventCount += g.Aggregate.Count
		}
	}
	if eventCount != uint64(n) {
		t.Fatal("aggregate event count mismatch")
	}
	encode := timed(t, 9, func() error {
		for _, v := range b.summaries {
			if _, e := encodeSummary(v); e != nil {
				return e
			}
		}
		return nil
	})
	decode := timed(t, 9, func() error {
		for _, raw := range rawRecords {
			var v Summary
			if e := decodeSummary(raw, &v); e != nil {
				return e
			}
		}
		return nil
	})
	read := timed(t, 9, func() error {
		return records(b.sum, func(raw []byte) error { var v Summary; return decodeSummary(raw, &v) })
	})
	queries := map[string]timing{}
	for _, q := range []struct {
		name     string
		from, to time.Time
	}{{"all", from, to}, {"day", from.AddDate(0, 0, 15), from.AddDate(0, 0, 16)}, {"three_hours", from.AddDate(0, 0, 15).Add(9 * time.Hour), from.AddDate(0, 0, 15).Add(12 * time.Hour)}} {
		queries[q.name] = timed(t, 9, func() error { _, e := s.Summaries(Write, q.from, q.to); return e })
	}
	for day := from; day.Before(to); day = day.AddDate(0, 0, 1) {
		if e = s.PublishRollup(Write, Daily, day); e != nil {
			t.Fatal(e)
		}
	}
	rollupPath, _, _, e := s.rollupPeriod(Write, Daily, from)
	if e != nil {
		t.Fatal(e)
	}
	rst, e := os.Stat(rollupPath)
	if e != nil {
		t.Fatal(e)
	}
	rollupRead := timed(t, 9, func() error {
		var count uint64
		for day := from; day.Before(to); day = day.AddDate(0, 0, 1) {
			g, e := s.ReadRollup(Write, Daily, day)
			if e != nil {
				return e
			}
			for _, a := range g {
				count += a.Count
			}
		}
		if count != uint64(n) {
			return fmt.Errorf("rollup count mismatch")
		}
		return nil
	})
	saveMeasurement(t, map[string]any{"events": n, "fixture_sha256": hash, "go": runtime.Version(), "platform": runtime.GOOS + "/" + runtime.GOARCH, "aggregate_rows": groupCount, "aggregate_events": eventCount, "sum_bytes": stat.Size(), "rollup_bytes": rst.Size(), "ingest_ns": ingest, "reopen": reopen, "encode": encode, "decode": decode, "file_read_decode": read, "query": queries, "rollup_read_30_days": rollupRead})
}
