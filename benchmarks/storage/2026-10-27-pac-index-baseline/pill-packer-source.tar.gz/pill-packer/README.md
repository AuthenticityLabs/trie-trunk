# Pill Packer

Portable codecs for **PIL (Positional Interchange Layout)** and **PAC (Packed Array Container)**.
Encode typed values by field position, distinguish absent fields from nulls,
and read packed records without expanding every field into an object.

[Format & Specification](https://github.com/AuthenticityLabs/pill-packer/blob/main/README.md)

<a id="pack-proposal"></a>

## Proposed Pack Conventions — Design for Review

**Status: proposal, not an implementation announcement.** The APIs, named PAC
headers, embedded offset directories, and fixed-width PAC mode in this section
are being specified before refactoring. The existing libraries and wire format
are documented below under [Current libraries](#current-libraries) and
[Current format reference](#current-format-reference). Version zero remains
under development; this document does not assign new wire identifiers or promise
compatibility with proposed bytes that no implementation writes yet.

PIL is **Positional Interchange Layout**. PAC is **Packed Array Container**.
One Definition describes one PIL record. One PAC contains an ordered collection
of PIL records bound to that exact Definition. A record can itself contain
schema-defined arrays and child records. PAC member access addresses the outer
PIL records; access inside a field follows that field's Definition.

Pill Packer supplies layout encoding, packing, compression, and access primitives.
The application chooses record shape, grouping, pack size, headers, validation
policy, storage, and indexes. The same Definition can be used to pack any
application-selected subset of its records. The library assigns no meaning to
the contents or to application file names.

### Definition and record preparation

The following is language-neutral pseudocode. It proposes a shared contract
across Rust, Go, and JavaScript/WASM, not currently callable package exports:

```ts
import * as pill from "pill-packer";

const rxBytes = pill.rx.write(cddlJsonBytes);
const cddlJsonAgain = pill.rx.read(rxBytes);
const definition = pill.define(rxBytes); // prepare once, reuse

const first = pill.fill(definition, [
  field0Bytes,
  field1Bytes,
  pill.absent,
  pill.null
]);

const pils = [first, externallyPreparedPilBytes]; // complete PIL byte sequences
```

- `rx.write` compiles supported CDDL schema JSON to a PIL-encoded `.rx` document.
  `rx.read` renders that document's schema as JSON. CDDL source text remains an
  authoring input supported by the existing CLI. JSON is outside the binary
  record and PAC paths.
- `define` retains the exact Definition bytes, digest, and reusable layout
  information. Preparing a Definition is a separate cost from filling records.
- `fill` accepts field payload bytes in Definition order. It writes the state
  mask, integer selectors where applicable, DIRECT values, offsets, and variable
  payloads. Explicit absent and null markers distinguish both states from present
  empty bytes. It validates payload representation and schema constraints.
- Encoded arrays and nested records follow their declared layouts. Generic
  array/child-record helpers should be available through the same library.
  A private byte block is opaque unless its structure is described in `.rx`.
- Applications may prepare valid PIL bytes themselves and pass them directly to
  `pack`. Calling `fill` is optional. Equivalent validation and record semantics
  apply to either producer; performance measurements decide which is suitable.
- A normal `fill` result owns its output bytes. A reusable-buffer variant is a
  proposed optimization to measure separately; overwriting its buffer invalidates
  any borrowed bytes. Borrowing and allocation must be explicit in each binding.

The Definition governs the PIL representation. Choosing a PAC layout or codec
does not change field meaning, synthesize absent values, or alter null semantics.

### Packing API and application headers

```ts
const cpack = pill.pack(definition, pils, {
  layout: { kind: "variable" },
  packing: { commonValues: true },
  compression: { algorithm: "gzip", level: compressionLevel },
  headers: {
    "Batch-Id": batchIdBytes,
    "Producer": producerBytes
  },
  index: { addressBytes: 3 }
});

// The bytes can be stored or transmitted without a second serialization pass.
const storedBytes = cpack.bytes;
```

Header names identify metadata fields; their values are opaque bytes. The object
above represents ordinary named headers, such as `Batch-Id: <bytes>`. It is not a
list of numeric extension descriptors. The library preserves custom header bytes
and returns them when opening a pack. Their interpretation belongs to the caller.

The proposed custom-header representation is a length-delimited collection of
UTF-8 names and byte values. Names are nonempty and case-sensitive. Writers sort
names by encoded bytes for deterministic output. Readers reject duplicate names,
invalid lengths, invalid name encoding, and collisions with reserved structural
names. Empty values are valid. Unknown custom headers are preserved. Applications
enforce their own required custom-header names and value formats.

Mandatory structural header fields describe the container:

| Information | Supplied or computed |
| --- | --- |
| Exact Definition digest | Computed from the bound `.rx` bytes |
| Record count and stored/decoded lengths | Computed from the completed pack |
| Packing choices and compression codec/decoder parameters | Recorded from the requested options |
| Member region boundaries and common-value metadata | Computed during packing |
| Variable addressing mode and optional directory address width | Recorded from the requested options |
| Fixed record width, when selected | Derived and verified, or checked against the supplied width |

These fields have defined binary representations. Applications cannot overwrite
them through custom headers. The exact byte offsets and discriminators for the
proposed additions will be specified before codec changes.

Minimal options mean variable members, no common-value factoring, no compression,
no embedded index, and no custom headers. Full validation is the default.
Applications explicitly enable the work and metadata they need.

### Three addressing strategies

All three strategies retain the same logical PIL values and record order.

| Strategy | Requested options | Address metadata | Locating record `i` after opening |
| --- | --- | --- | --- |
| Variable, sequential | `layout: {kind: "variable"}, index: false` | Count and member extent | Traverse preceding record boundaries |
| Variable, indexed | `layout: {kind: "variable"}, index: {addressBytes: 2 \| 3 \| 4}` | Count plus packed starting offsets | Read adjacent directory entries |
| Fixed width | `layout: {kind: "fixed"}, index: false` | Record width and count | `memberStart + i * recordWidth` |

Compression is an independent choice for every strategy. There is no requirement
to index variable records, or to turn a fixed-width pack into an indexed pack.

#### Variable records with an optional embedded index

The directory stores one unsigned little-endian starting offset per member.
Offsets are relative to the beginning of the **decoded member region**, after
packing and common-value factoring. They never refer to compressed byte positions
or to the original input buffer.

For `N` members and address width `w`, the directory costs `N * w` bytes in the
decoded pack. The next starting offset gives the current record's end; the last
record ends at the member region's declared end. No extra terminal entry is needed.

| Address width | Bytes per member | Largest representable starting offset |
| --- | ---: | ---: |
| 2 | 2 | 65,535 |
| 3 | 3 | 16,777,215 |
| 4 | 4 | 4,294,967,295 |

The width must represent every stored starting offset, subject also to the
container's overall length limits. The final member end is supplied by the member
extent, not another narrow directory entry. Choose width from the final decoded
offsets, not record count or compressed size. Overflow is an error; a requested
width is never silently widened or split into multiple packs.

The first offset is zero. Remaining offsets must increase strictly and stay
within the member region; each range must contain exactly one member. An empty
pack has an empty directory. Readers check directory length against record count
and width, and enforce their chosen validation and resource limits.

Normally the packer generates this table while writing final members. Common
factoring can change member sizes, so input-PIL offsets are not sufficient.
A caller-supplied table may be accepted as:

```ts
index: { addressBytes: 3, offsets: packedOffsetBytes }
```

Its bytes must match the final member layout exactly. The writer can check that
during its existing member pass. Supplying a table cannot bypass bounds or
consistency checks. Validation cost must be reported separately from generation
cost in benchmarks.

Applications may continue to use external directories. They must bind an external
directory to the exact pack representation and offset base. An embedded directory
removes that separate binding requirement; it does not replace application lookup
indexes that map keys to a pack and record number.

#### Fixed width: record width and record count

```ts
const upack = pill.pack(definition, pils, {
  layout: { kind: "fixed", recordWidth: expectedWidth },
  packing: { commonValues: false },
  compression: { algorithm: "none" },
  headers,
  index: false
});
```

`recordWidth` is the size of each **final stored member**, including its ordinary
PIL masks and any field offsets. It excludes the PAC header and common frame.
The packer verifies equal member lengths after all selected packing operations.
It also verifies `memberBytes == recordWidth * recordCount` with checked arithmetic.
A supplied width is a constraint, never an instruction to pad records.

For nonempty packs, the width may be omitted and derived from the first final
member, then verified against every remaining member. An empty fixed-width pack
requires an explicit positive width. Width metadata and count are sufficient for
addressing, so the lighter fixed strategy omits the directory. A caller may
explicitly request a redundant directory for a uniform consumer interface; its
offsets must agree with the verified width and its extra cost is measured.

Fixed scalar types alone do not guarantee a fixed record size: presence states,
adaptive integers, arrays, and variable payloads can change lengths. Conversely,
records containing variable fields may qualify when their actual final lengths
are equal. The fixed mode verifies bytes; it does not infer a presence contract
or reserve false positions for absent fields.

A failed fixed-width request is an error. The library does not pad, fabricate
values, truncate, or silently switch to variable mode. Common-value factoring
remains available when explicitly selected, but its final members must still
satisfy the requested width.

### Common values, compression, and UPack/CPack

Common-value factoring is a generic packing operation. It compares encoded field
states and bytes at corresponding positions under the same Definition. Equal
fields can be stored once and inherited by members. It neither aggregates
records nor assigns meaning to fields. Codec-specific transforms, if added, must
be explicit, reversible, and described by generic metadata; opaque application
payloads are not privately transformed by the packer.

`UPack` means an uncompressed PAC representation. `CPack` means a compressed
representation that expands to a UPack. These are representation names and handle
types, not required filename extensions or different logical record collections.

The proposed compressed representation wraps the complete UPack, following the
current whole-container compression model. Its small outer control header records
the codec and necessary framing/decoded-size controls. Named headers, common data,
and any offset directory are inside the decoded UPack and become available on
unpack. Compression cost and compression of directory/header metadata must be
measured explicitly.

The caller chooses compression through the pack request. Initially `none` and
`gzip` are the implemented-codec targets for the proposed API. A generic codec
registration mechanism should allow other algorithms without application-specific
branches: a stable codec identifier, encoder, bounded decoder, and any required
decoder parameters. Registering a codec is explicit; unknown codecs are rejected.

A requested codec is honored even if it expands the input. Falling back to
uncompressed output is allowed only through an explicit caller policy such as
`onlyIfSmaller: true`. The returned handle and serialized discriminator identify
the representation actually produced. Compression effort is selected by the
caller; a codec has no hardcoded workload-specific level or threshold.

### Opening and retrieving records

```ts
const { pack: upack, headers } = pill.unpack(definition, cpack.bytes);

const record = upack.pop(17);                    // zero-based record number
const sameRecord = upack.pop({ index: 17 });      // explicit equivalent
const byAddress = upack.pop({ offset: offset }); // decoded member-relative start
```

`unpack` accepts compressed or uncompressed PAC bytes, verifies the Definition
binding and framing, and returns an opened UPack plus its named headers. The
compression discriminator selects the registered decoder; callers need not repeat
the packing algorithm to decode a self-describing pack. Allowed codecs, limits,
and validation policy can be supplied separately as reader options.

An opened UPack retains its Definition, common data, member extent, and addressing
information. It holds any reusable traversal state. Packing an uncompressed result
can return an already opened handle, avoiding a serialize-and-rescan cycle.

`pop` is the proposed extraction name: it returns a complete standalone PIL and
does **not** remove or renumber records. An integer always means record number;
byte-offset access is explicit. Offsets must identify actual member starts.
For fixed members, alignment checks locate valid starts. With a directory, lookup
can establish membership. Without one, verifying a supplied offset may require
traversal. A position inside a member is invalid.

Common fields must be restored when returning a standalone PIL. Locating a member
can be constant time while reconstruction/copying still costs time proportional
to the returned record size. A borrowed view API may expose common/member spans
for readers that do not need standalone bytes; it must document lifetime and
mutability instead of hiding copies.

Full validation may scan all members when opening even an indexed or fixed pack.
Trusted reception can use explicitly selected structural checks after establishing
producer validation and integrity. Opening cost, validation cost, and subsequent
member lookup cost must be measured separately.

Opening an unindexed pack must not silently allocate a complete offset table.
Validation can scan without retaining every boundary. Any auxiliary in-memory
index is an explicit opt-in with its own allocation and construction costs.
Fixed-width addressing likewise needs no allocation proportional to record count.

Whole-pack compression requires expanding the pack before direct member access.
An offset directory or fixed stride does not enable seeking within a gzip stream.
`pop` on an opened UPack must not repeatedly decompress the original bytes.
Independently compressed blocks would be a separate optional strategy requiring
its own access, size, and CPU evaluation.

Application indexes can store `(pack identity, record number)` instead of a full
member byte address. Their record-number width depends on member count. It is
independent of the PAC directory's byte-offset width. For example, 50,000 records
fit two-byte ordinals while their member region may need three-byte offsets.

### Baseline and cost evaluation before refactoring

**No results for the proposed modes are claimed here.** Capture the current
implementation baseline before changing behavior. Record the revision and exact
working-tree source snapshot, toolchain versions, platform, build flags, fixtures,
and deterministic input seeds. Existing Rust codec/reference benchmarks are
starting points, not evidence that the proposed pack modes already exist.

Build a generic benchmark harness in this repository. Application-specific
integration measurements and data generators belong in their consuming projects.

| Dimension | Cases |
| --- | --- |
| Producer | Existing external PIL builder; library `fill`; reused-output-buffer variant |
| Record shape | Dense equal-width records; sparse records; variable strings/bytes; arrays and nested values |
| Addressing | Variable scan; variable index at 2/3/4 bytes when representable; verified fixed width |
| Packing | Common values disabled/enabled; low/high repetition; mixed presence states |
| Compression | None; gzip-1; gzip-6; additional registered codecs only when implemented |
| Read workload | Whole-pack traversal; first/middle/last lookup; seeded random lookups; repeated access to an opened pack |
| Reader policy | Full validation; eligible structural/trusted reception, reported separately |
| Pack size | Empty/singleton, small batches, tens of thousands, and large batches up to configured limits |

Use identical logical records, ordering, headers, grouping, and codec effort for
each valid comparison. Fixed-width comparisons use records that actually qualify;
they must not introduce dummy values or drop fields to make a fixture fit.
Inapplicable narrow-index cases are reported as inapplicable. Address-width
boundary fixtures exercise offsets around 65,535/65,536 and
16,777,215/16,777,216. Additional checks cover empty packs, arithmetic limits,
malformed directories, absent/null/empty values, and exact integer preservation.

Measure and report:

- Definition preparation and schema compilation separately from record operations.
- Fill, pack, and optional directory generation/validation time, including
  allocations and allocated bytes per record or pack.
- Header, common-data, directory, member, and total byte sizes before and after
  compression. Indexed directory overhead starts at `recordCount * addressBytes`;
  fixed width has constant width/count metadata and no member directory.
- Decompression, opening/validation, traversal, index construction for an
  unindexed opened pack if offered, lookup, and standalone-record reconstruction.
- Throughput, repeated-sample latency distributions, retained memory, and peak
  memory. Include data copies and temporary buffers in the cost.
- Cold opening versus repeated lookups on one already opened pack. Separate
  in-memory codec measurements from storage I/O, FFI/WASM crossings, and rendering.
- Optional sidecar versus embedded directories, and short application ordinals
  versus full byte addresses, in integration reports.

Use optimized builds, warm-up where applicable, repeated runs, and retained raw
results. Report measurement variability and any runtime/OS cache limitations.
Exercise Rust, Go, and JavaScript/WASM for representation agreement and identify
which binding each timing measures. Existing baseline commands include:

```sh
cargo bench --locked --manifest-path rust/Cargo.toml --bench codecs
cargo bench --locked --manifest-path rust/Cargo.toml --bench shared_refs
```

The proposed PAC strategy benchmark harness is additional work; no new benchmark
command is presented as runnable yet. Baseline capture must precede refactoring,
and each implementation step should include targeted correctness checks and a
comparable cost report. Avoid using historical payload-size examples below as
performance evidence for a new addressing or compression strategy.

### Proposed implementation sequence

1. Review this API contract and specify the binary header, layout descriptors,
   named-header encoding, directory placement, and codec identifiers.
2. Capture a reproducible baseline of current behavior and build the comparison
   fixtures without changing their record semantics.
3. Implement the generic fill/pack/open/extract contract and optional addressing
   modes in the existing Rust and Go codec layers. Expose matching FFI and
   JavaScript/WASM APIs; reuse existing encoders, validators, and scanners.
4. Check cross-binding round trips, header preservation, common-field restoration,
   fixed-width verification, directory bounds, and explicit codec policies.
5. Evaluate each strategy against the baseline before applications adopt it.
   Applications then choose their own grouping, record construction, header
   values, and indexing/compression policy.

Named PAC headers, embedded indexes, and fixed-width PACs are all proposals in this
section. Current numeric extensions, external directory helpers, and current
compression behavior are described below as existing behavior, not as the agreed
implementation of this proposed API.

## Current Libraries

| Library | Location | Available APIs |
| --- | --- | --- |
| Rust | `rust/` | PIL encoding/decoding, borrowed scans, PAC reading, optional gzip and JSON definition import |
| JavaScript / WASM | `npm/`, `rust/wasm/` | Rust-backed validation, portable PAC/header readers, frame composition, bounded gzip and column transforms |
| Go / C | `go/`, `rust/ffi/`, `include/` | Rust C ABI bindings for definition import and scanning |
| Go Codec | `go/codec/` | PIL encode/decode and streaming writes, PAC factoring/writing/reading, compression and column transforms |

Definitions describe ordered fields, binary types, and string dictionaries.
They are stored as binary PIL files with the `.rx` extension, including their
structured CDDL schema annotations. The fixed bootstrap is published as
[`schemas/pil.rx`](schemas/pil.rx). Their structure is described by [CDDL](https://github.com/AuthenticityLabs/pill-packer/blob/main/schemas/definition.cddl); runtime
validators enforce semantic rules. The document API preserves unknown annotations.
Applications own routing, storage, delivery, and consistency policies.

This is an early implementation. Packages are not yet published to registries.
The Go scalar codec is implemented in Go; its compiled nested-schema support
uses the shared Rust runtime through the native bindings.
Rust, Go and JavaScript APIs do not yet have full feature parity. Cross-language
fixtures verify their shared wire formats. The optional Rust `schema` feature
compiles a supported CDDL subset into PIL layouts and a JSON-editable schema.
Unsupported constructs fail explicitly; full CDDL support is not claimed.

Pill Packer owns PIL field layouts, adaptive integers, arrays, PAC common-value
factoring, PAC headers, gzip compression/decompression, numeric base residuals,
and byte shuffling. Applications supply schemas and choose whether and when to
compress. Version zero defines gzip as its only PAC compression codec; callers
can select gzip effort through the compression API. Adding other PAC codecs
requires a versioned discriminator and implementations in each binding. Sealing
schedules, storage placement, aggregation, retention, replication, and eviction
remain application responsibilities. Numeric column transforms are reusable
codec primitives, while their use in an enclosing container is defined by that
container's own format.

The Go codec import is `github.com/AuthenticityLabs/pill-packer/go/codec`.
JavaScript helpers are exported as `pill-packer/layout`, `pill-packer/pac`,
`pill-packer/gzip`, `pill-packer/columns`, `pill-packer/object`, and
`pill-packer/cbor`. The package root exposes the Rust/WASM reader.

## Command-Line Reader

Build and install the `rx` executable:

```sh
cargo install --path rust --locked --features cli --bin rx
rx read definition.rx records.pil
rx read definition.rx records.pac
rx read definition.rx records.pac.gz --pretty
rx read definition.rx
rx definition.rx --pretty
rx write definition.json definition.rx
rx bootstrap pil.rx
```

`.rx` names a definition document; `.pil` names a record stream and `.pac`
names a record pack. Every `.rx` document, including the structured CDDL schema
inside its `cddl` annotation, is encoded entirely in PIL. JSON and `.cddl` files
are editable authoring inputs. There is no JSON or CDDL text envelope in `.rx`.

`schemas/pil.rx` describes the fixed seven-field `pil/value` layout used to encode
all definition documents, including itself. Readers have this one small layout
built in, so no network lookup or infinite chain of definitions is required.
`rx bootstrap pil.rx` reproduces the published bytes; `rx read pil.rx --pretty`
inspects it, and `rx read pil.rx pil.rx` reads its own PIL encoding through the
layout it describes.

Records print as JSONL by default. `--pretty` prints each record as indented
JSON; omit the data path to print the Definition itself. Absent fields are
omitted and explicit nulls remain null. Bytes are JSON octet arrays, UUIDs are
dashed hexadecimal strings, timestamps retain their declared integer units,
and integer output preserves the full signed/unsigned 64-bit range. PAC common
fields are merged before rendering. The reader validates definition digests,
required extensions, field values, framing, compression bounds and checksums.
It accepts adjacent PACs, Go-compressed PACs, and external gzip streams. `-`
reads records from stdin or writes binary definition bytes to stdout.

`rx write` accepts a JSON layout Definition (including application annotations)
or the JSON-editable CDDL schema model. It writes binary PIL; `--pretty` applies
to JSON read output. To compile CDDL source, name its root rule explicitly:

```sh
rx write purchase.cddl purchase.rx --root purchase
rx read purchase.rx --pretty > purchase.json
# Edit the schema JSON, then compile it back to PIL:
rx write purchase.json purchase.rx
```

The CDDL compiler supports named nonrecursive rules, closed text-keyed records,
required/optional members, homogeneous arrays with occurrence bounds, choices,
literals, uint, bool, float64, text, bytes, null, bounded 64-bit integer ranges,
and supported `.size` constraints. It rejects recursive rules, dynamic maps,
generics, group rules, tuple arrays, unbounded `int`/`nint`, and unsupported
controls. JSON byte values are octet arrays. The PIL document contains an ordinary
root Definition plus a `cddl` annotation with the editable schema. Rust, Go, and
WASM load the same compiled schema runtime and validate nested layouts. The
layouts are derived together; full schema checks run during encoding and
ordinary decoding, while `decode_trusted_json` performs structural decoding
only.

A schema's `fixed_strings` map binds qualified field paths (for example,
`purchase.customer.name`) to byte capacities. Bindings must cover a bounded
CDDL text size. `STRING(n)` uses a 1/2/4-byte little-endian length prefix for
capacities up to 255/65,535/U32 maximum, followed by exactly `n` UTF-8 bytes
with zero padding. Shorter strings, trailing spaces and embedded NULs survive;
overflow, malformed UTF-8 and nonzero padding are errors. This storage choice
does not change the CDDL size constraint.

## Validation and Trusted Reception

Full validation remains the default: Rust `FrameIndex::scan` and `PacIndex::scan`,
and JavaScript `scan` and `pac`, validate field values as well as framing.
`scan_structural` / `scanStructural` and `scan_pac_structural` / `pacStructural`
retain bounds, offsets, masks, type widths, and PAC framing checks while skipping
semantic field validation. Use these when the producer has already validated the
values and the receiver has established transport integrity.

Rust `checksum::crc32c` and JavaScript/WASM `verifyCRC32C(bytes, expected)` provide
CRC32C (Castagnoli) verification. The expected checksum must come from the trusted
transport or storage manifest; CRC32C detects corruption, not authenticity.
Compression retains its own framing and integrity checks.

For a validated member-offset directory, `indexedPACBounds(header, index, stride,
offset)` constructs member ranges without scanning PIL fields. It checks directory
shape and monotonic in-bounds offsets. The application verifies both the PAC and
the directory before using this path, binds them to the same definition and block,
and owns storage publication ordering. These APIs do not change the wire format.

## Current Variable-Length Records

PIL records and PAC members remain variable length. A Definition specifies field
types, ordering, dictionaries and schema constraints; it does not imply that
all fields occur in every record. ABSENT and NULL retain their distinct meanings,
and absent fields do not receive fabricated values or reserved payload slots.
Fixed-width scalar types and fixed-capacity strings remain supported when
present, without imposing a fixed record stride.

CDDL schema validation uses the shared runtime across language bindings.
Application-specific validation remains the responsibility of the consuming
system and is not duplicated in the CDDL compiler.

## Nested-Object Experiment

The Rust [nested-object example](rust/examples/nested_objects.rs) composes a
purchase, customer, address, and variable-length item list from existing PIL
frames. Their logical types are declared together in
[nested_objects.cddl](rust/examples/nested_objects.cddl), using named CDDL rules.
This original experiment uses handwritten layout bindings. The `schema` feature
now compiles the supported CDDL subset; `OBJECT` separately carries open values
using the built-in native PIL value layout.

Nested objects occupy `BYTES` fields; object lists use `ARRAY<BYTES>`, with each
body containing another PIL frame. The containing layout supplies the child
layout, without a per-child definition identifier. Record payloads contain no
CBOR. Definitions now also use native PIL. The CDDL compiler supplies portable
child-layout bindings and generic recursive
validation before other codecs can interpret these byte fields as objects.

```sh
cargo test --locked --manifest-path rust/Cargo.toml --all-features --example nested_objects
cargo run --locked --release --manifest-path rust/Cargo.toml --all-features --example nested_objects
```

Five tests check semantic round trips against CDDL, Unicode, absent/null/empty
values, empty and long lists, malformed nested frames, required fields, scalar
widths, and zero-allocation borrowed traversal after warming reusable offsets.
The encoder and the test's logical-object projection still allocate; only the
borrowed reader has the zero-allocation guarantee tested here.

A deterministic 10,000-purchase sample (one to five items per purchase) produced:

| Representation | Payload Bytes | Gzip-6 Bytes |
| --- | ---: | ---: |
| Nested PIL frames | 1,262,230 | 179,101 |
| CBOR sequence with named fields | 2,122,480 | 197,720 |
| Compact JSONL | 2,806,680 | 190,934 |

These are identical logical records, with no indexes, PAC factoring, or shared
compression dictionary. The original benchmark used 450 bytes for four layout
documents; that older Definition encoding is not the current PIL wire size. The
CDDL source is 251 bytes. PIL reduced raw size substantially, but its compressed
advantage over JSONL was only about 6.2% on this sample. This is a codec experiment,
not a production storage or throughput claim. The example also prints a local
microbenchmark for full nested structural validation and borrowed projection;
CDDL validation is a separate conformance check, outside that timed path.

## Build & Test

Requires Rust 1.88+, Go 1.24+ and a C toolchain for Go bindings, and Node.js 22+
for JavaScript package tooling. Run from a source checkout:

```sh
git clone https://github.com/AuthenticityLabs/pill-packer.git
cd pill-packer

# Rust codec and example
cargo test --locked --all-features --manifest-path rust/Cargo.toml
cargo run --locked --manifest-path rust/Cargo.toml --example roundtrip

# JavaScript / WASM
rustup target add wasm32-unknown-unknown
npm --prefix npm install
npm --prefix npm run build
npm --prefix npm test

# Native library, Go codec, and Go wrapper
cargo build --locked --release --manifest-path rust/ffi/Cargo.toml
cargo test --locked --manifest-path rust/ffi/Cargo.toml
go -C go test ./codec
go -C go test -race ./...
```

The native build produces static and shared libraries plus the public
[header](include/pill_packer.h). Go links the static library from this checkout;
build it for the host platform before using the wrapper. The Go import path is
`github.com/AuthenticityLabs/pill-packer/go` (package `pillpacker`).

Close Go definition handles explicitly. Calls on one handle are serialized;
independent handles can run concurrently. WASM instances are worker-local.
Definitions must be supplied before their records can be decoded.

## Current Format Reference

**Project:** Version zero; not a frozen interoperability standard.

This section describes the currently implemented format. The proposed pack
conventions above add named headers and optional addressing modes that are not
implemented by this layout yet. Applications own their storage and delivery
bindings.

PIL exchanges structured state under a shared, immutable Definition. Field
positions replace names, dictionaries replace repeated strings, and cumulative
end offsets locate variable values. A frame may carry a complete object or a
partial change; that distinction belongs to the application. PIL does not
prescribe storage, routing, subscriptions, or query execution.

### 1. Definition

The wire Definition is PIL, using the built-in `pil/value` bootstrap layout. [definition.cddl](schemas/definition.cddl) describes its
portable structure and extensible annotations; codec validation additionally
enforces semantic rules. This JSON illustration uses the same data model:

```json
{
  "pil": 0,
  "definition": "example/records",
  "version": 0,
  "fields": [
    { "name": "id", "type": "UUID" },
    { "name": "revision_id", "type": "U64" },
    { "name": "state", "type": "STRING", "values": ["pending", "authorized", "canceled"] },
    { "name": "description", "type": "STRING" },
    { "name": "@fields", "type": "OBJECT" }
  ]
}
```

- `definition` is a nonempty identity; `version` is an unsigned integer.
- `fields` is a nonempty **ordered array**. Position identifies each field.
  Names must be nonempty and unique; map-key order has no field-order meaning.
- `values`, when supplied, is an ordered dictionary of unique strings for a
  scalar `STRING` field. Array position is the zero-based dictionary ID.
- Optional `adaptive_integers` is `"none"`, `"16"`, or `"32"` (§4).
- The current codec requires `pil: 0` for fixed integers and `pil: 1` for enabled
  adaptive integers. These existing layout selectors are distinct from the
  Definition's `version` and PAC/0. Transport bindings have their own selectors.

Publish Definitions immutably. Changing types, order, fields, dictionary contents,
or integer policy requires a new Definition binding, even for an additive
change. Adding entries to a declared `@fields` value does not change its Definition.
A frame contains no Definition identifier: its enclosing binding must supply the
exact Definition before decoding. A structurally compatible wrong Definition
cannot be detected from a standalone frame alone.

Applications may attach resource/transport/profile annotations. Generic PIL
does not prescribe application identities, revisions, tree structures, or
resource bindings.
Bindings using a digest retain the exact original Definition document bytes;
reserializing a semantic equivalent need not preserve its digest. JSON imports
produce PIL once at registration. Bootstrap map entries are sorted by their
encoded keys; ordered field arrays and dictionary arrays retain their order.
Forwarding preserves the exact accepted document bytes and annotations.

### 2. Types and Byte Conventions

All multibyte numbers are little endian. Signed integers use two's complement;
floats use IEEE-754. UUIDs are the exception: their 16 bytes follow standard UUID
network/textual-hex order. UUIDv7's first six bytes hold its millisecond timestamp;
the generic UUID primitive does not require version 7.

| Type | Value representation |
|---|---|
| `BOOL` | 1 byte: `00` false, `01` true; other values invalid |
| `I8/I16/I32/I64`, `U8/U16/U32/U64` | 1/2/4/8 bytes, subject to §4 |
| `F32`, `F64` | 4/8 bytes |
| `UUID` | 16 bytes |
| `TIMESTAMP_MS`, `TIMESTAMP_US`, `TIMESTAMP_NS` | Signed 8-byte Unix time; Definition supplies the unit |
| `REF16` | Opaque unsigned 2-byte shared-value reference, 0–65,535 |
| `STRING` | UTF-8 bytes, or a DIRECT dictionary ID |
| `STRING(n)` | Fixed UTF-8 byte capacity, explicit length, then zero padding |
| `OBJECT` | One native PIL bootstrap value, including nested objects and arrays |
| `BYTES` | Arbitrary bytes |
| `ARRAY<T>` | Homogeneous scalar elements; layout in §6 |

There is no bare `TIMESTAMP` type or implicit unit inference. REF16's target and
scope must be supplied by the binding; PIL reserves no REF16 value and does not
interpret the target. A dictionary ID instead refers to its own
field's Definition dictionary and uses the smallest width covering its largest ID:
1–256 entries → U8; 257–65,536 → U16; up to 2³² → U32; larger → U64.
No dictionary ID is an extension sentinel. Out-of-range IDs are invalid.

### 3. Frames and Field States

```text
[field-state mask]
[integer-width mask, if applicable]
[DIRECT values]
[variable End Offsets]
[contiguous variable values]
```

For N fields, the state mask occupies `ceil(N / 4)` bytes. Each field has two
bits, first field in bits 7–6, then 5–4, 3–2, 1–0. Unused low bits are zero.

| Bits | State | Meaning and bytes |
|---|---|---|
| `00` | ABSENT | No value supplied; no value bytes |
| `01` | NULL | Explicit null; no value bytes |
| `10` | DIRECT | Fixed-width value or dictionary ID in the DIRECT section |
| `11` | OFFSET | One cumulative End Offset and a value in the variable section |

ABSENT and NULL are distinct. Applications decide how absence affects a complete
object or a patch; PIL does not turn NULL into deletion. Ordinary scalar layouts
permit both states; `@fields` forbids NULL. A compiled CDDL schema can further
constrain presence and nullability. Arbitrary annotations do not add validation
rules (§10).

Fixed-width types accept DIRECT, not OFFSET. Unmapped STRING, BYTES, OBJECT, and
arrays accept OFFSET, not DIRECT. A mapped STRING accepts either an in-range
DIRECT ID or a literal OFFSET string, including a string present in its dictionary.
The encoder does not automatically replace literal strings with dictionary IDs.

Within each section, values appear in Definition order for fields using that
section. Offsets count bytes from the beginning of the variable section:

```text
start(first variable) = 0
start(next variable)  = previous End Offset
length                = End Offset - start
```

Offsets are nondecreasing; equal offsets permit empty strings/bytes. Values are
contiguous with no padding. The final End Offset is the variable section length.
Frame length is the prefix through the offset table plus that final offset; with
no OFFSET fields, it ends after DIRECT values. There is no standalone frame-length
prefix. Discovering the boundary requires parsing the masks and offset encodings,
not decoding the variable payloads. Consecutive frames can share a Definition.

Example, fixed layout `[state STRING(values=[pending,authorized]), note STRING]`:

```text
state = authorized, note = "OK"
B0 | 01 | 02 00 | 4F 4B
mask direct  end   UTF-8
```

`B0` is `10 11 00 00`: DIRECT, OFFSET, then zero padding. Total: six bytes.

### 4. Adaptive Integers

The Definition controls shortening; declared types and valid ranges remain strict.

| `adaptive_integers` | Eligible scalar fields |
|---|---|
| `none` / omitted | None |
| `16` | I16/U16, I32/U32, I64/U64 |
| `32` | I32/U32, I64/U64 |

Each present DIRECT eligible integer contributes a selector to a **separate**
packed width mask immediately after the state mask. ABSENT/NULL fields contribute
no selector. Selectors are MSB-first in field order, may cross bytes, and have
zero final padding. Full-width values still contribute selectors.

| Declared width | Selector | Stored widths |
|---|---|---|
| 16 bits | 1 bit | `0`=1 byte, `1`=2 bytes |
| 32 bits | 2 bits | `00`=1, `01`=2, `10`=4; `11` invalid |
| 64 bits | 2 bits | `00`=1, `01`=2, `10`=4, `11`=8 |

Use the smallest lossless width. Signed values are shortened two's complement
and sign-extended when read. Reject nonminimal encodings. U8/I8, REF16, dictionary
IDs, timestamps, floats, and array elements never adapt. There is no automatic
per-frame fallback. The selector-byte overhead can erase a sparse record's saving
or grow a full-width record; enable this deliberately per Definition.

### 5. Extended Unsigned Integers

Counts, End Offsets, and PAC variable lengths use this canonical encoding:

| Value | Encoding | Bytes |
|---|---|---:|
| 0…65,534 | U16(value) | 2 |
| 65,535…4,294,967,294 | U16(65,535), U32(value) | 6 |
| 4,294,967,295…2⁶⁴−1 | U16(65,535), U32(4,294,967,295), U64(value) | 14 |

Encoders and decoders require the shortest form. This length encoding is separate
from adaptive scalar integers and dictionary IDs.

### 6. Arrays

Arrays always occupy one OFFSET field. The parent field's boundaries contain the
entire array, including its count and offset table.

```text
Fixed-width T:   [extended count][value₁]...[valueₙ]
Variable T:     [extended count][extended end₁]...[extended endₙ][values...]
```

For STRING/BYTES/OBJECT elements, ends are cumulative byte offsets relative to the
**element-value section**, not the array start. The final end must equal that
section's length; fixed-width size must equal `encoded_count_size + count × width`.

Example STRING array: `[3][5][10][19][JasonSmithAlexander]` (conceptual integers).
An empty array is the two-byte count zero alone, distinct from ABSENT and NULL.
Elements cannot be absent or null; `ARRAY<OBJECT>` rejects a top-level native null element
but permits nulls inside complex items. Use `OBJECT` for native nested structures,
or CDDL-compiled nested frames in `BYTES`/`ARRAY<BYTES>`. There is no ARRAY<PIL> type: use a sequence or PAC for
Definition-bound PIL records. Native arrays do not require PAC.

### 7. Native Objects and Dynamic Fields

`OBJECT` uses the same built-in `pil/value` layout as Definition documents.
The ordered fields are `kind:U8`, `unsigned:U64`, `negative:I64`, `float:F64`,
`text:STRING`, `bytes:BYTES`, and `children:ARRAY<BYTES>`. Kinds 0–9 represent
null, false, true, unsigned integer, negative integer, float, text, bytes,
array, and map. Only the payload selected by `kind` is present. Each child is
another bootstrap value; maps alternate text/integer keys and values, reject
duplicate keys, and sort encoded keys when writing. Codecs bound values to
16 MiB and nesting to 64 levels. This layout needs no external Definition.

CBOR is an external ingestion format only. `CBOR` and `ARRAY<CBOR>` are rejected
as PIL field types; ingress adapters decode them to native PIL objects before
storage or runtime processing.

Field names beginning with `@` are reserved. The only implemented reserved field
is explicitly declared `@fields: OBJECT`; omitting it disallows dynamic root fields.
When present it must be an OFFSET native PIL map with unique text keys, none beginning
with `@` or colliding with any defined field. Its entries represent additional
root attributes; `@fields` is not itself an application property.

The extension contract for partial state is: ABSENT leaves the dynamic attribute
set unchanged; a supplied map replaces that set, including `{}` to clear it.
NULL is invalid. The codec validates the representation; applying patches is an
application responsibility. Promoting a dynamic key into a defined field requires
a new Definition and removal of that key from `@fields` for frames using it.

### 8. PAC — Packed Array Container

PAC optionally groups ordered PIL records under one exact Definition. A common
frame can factor shared values at **arbitrary field positions**; positions need
not form a contiguous Definition prefix. PAC/0 is implemented in Go, Rust/WASM,
and the browser binding.

#### Decoded Binary Layout

| Offset | Bytes | Value |
|---|---:|---|
| 0 | 4 | U32 decoded container length, including header |
| 4 | 4 | U32 flags: bit 0 = common frame; other bits rejected in decoded PACs |
| 8 | 8 | U64 total decoded PAC length, including header |
| 16 | 8 | U64 header length / first member position |
| 24 | 8 | U64 member count |
| 32 | 32 | Exact Definition digest (SHA-256 of bound Definition bytes) |
| 64 | variable | Extended extension count, then extension entries |
| following | variable | Extended common-frame length, common PIL frame if present |
| header end | variable | Consecutive PIL member frames |

An extension is `[type U32][schema version U16][flags U16][extended length][bytes]`.
Current extension versions are zero; flag bit 0 means required. Types are singleton.
Skip unrecognized optional extensions by length; reject unsupported required ones,
unsupported versions of recognized types, and duplicates. Type 1 carries a UTF-8
source name. Other extension identifiers and their interpretation are owned by
application bindings. The host passes its supported identifiers to the decoder.

Header length includes extensions and common frame. Zero common length means no
prefix and requires the common flag to be clear. Empty PACs are valid. Member
count, self-delimited member lengths, and total PAC length must agree exactly.
Stored and decoded container lengths are bounded by U32. Readers must impose
resource limits before allocation; actual record counts are also bounded by the
decoded extent and member lengths.

#### Common-Field Semantics

- Any non-ABSENT common field applies to every member, including common NULL.
- That position must be ABSENT in every member; overrides are invalid.
- Positions ABSENT in the common frame retain their normal member meaning.
- Compare dictionary values and REF16 targets only under the same exact bindings.
- Group consecutive records without reordering search results to improve packing.

A packed member is structurally a PIL frame but needs its common frame to recover
the original logical object. Readers can borrow common/member field spans without
materializing maps or expanding repeated bytes. Standalone export must restore
inherited fields. A consumer may require companion indexes or metadata and must
declare that requirement through its extension.

PAC is not a pagination protocol or proof of delivery completeness. It does not
require compression or provide timestamp-base shortening.

#### Compressed Representation

Compression wraps the **entire decoded PAC**, including its header, extensions,
common frame, and records. A compressed PAC has this separate 16-byte header:

| Offset | Bytes | Value |
|---|---:|---|
| 0 | 4 | U32 stored length, including this wrapper |
| 4 | 4 | U32 codec discriminator: `2` = gzip; other compressed values rejected |
| 8 | 4 | U32 decoded PAC length |
| 12 | 4 | U32 record count |
| 16 | remaining | One gzip member containing the complete decoded PAC |

The discriminator shares its position with decoded PAC flags: `0` or `1` means
a decoded PAC; `2` means this compressed representation. Common-frame flags and
all semantic metadata exist only inside the compressed body. No outer routing,
Definition, common-prefix, or placement fields are added.

The library validates stored/decoded bounds, gzip CRC, absence of trailing data,
and agreement between wrapper length/count and the decoded header. Expansion
returns the original decoded PAC bytes exactly. The decoded header replaces the
wrapper; no wrapper fields are copied into or patched onto it. Borrowed PIL
scanners consume that decoded representation. Applications choose whether to
retain the compressed or uncompressed representation.

### 9. Validation and Transport Boundaries

Reject invalid masks/padding, type-state combinations, dictionary IDs, integer
selectors, noncanonical lengths, decreasing/out-of-range offsets, invalid UTF-8,
malformed arrays/objects, extension collisions, PAC overrides, and inconsistent
bindings/counts/lengths. Check arithmetic and resource limits before allocating
or reading. Distinguish truncated input that can receive more bytes from malformed
values within an already complete bounded frame.

HTTP/JMS negotiation, storage addresses, and routing are application/transport
bindings. A transport must supply the exact definition before dependent data.
HTTP content compression applies to a transport representation; PAC compression
belongs to each container and is decoded by the library. Neither requires a
particular datastore, time partition, record identity, or subscription protocol.
Compression does not imply encryption.

### 10. Proposal Status

The [proposed pack conventions](#pack-proposal)
describe the API and optional addressing work under review. The current PAC
format has numeric extensions, no embedded member-offset directory, and no
verified fixed-width mode. The current Go compressor can return uncompressed
bytes when gzip would increase the size; honoring a codec request with an
explicit fallback policy is part of the proposal.

Named PAC headers are container metadata supplied at packing time. They do not
require leading header fields in each PIL Definition or a change to the PIL
field-state mask. Generic Definition annotations have no implicit packing or
validation effect. Supported CDDL schemas separately enforce their declared
required members, nullability, and other implemented constraints.

The old speculative per-record header/body-compression design is not part of
this proposal. Any future format change requires coordinated codec/binding
checks and measured costs. Existing readers must reject unsupported layout or
codec identifiers rather than interpreting proposed bytes as the current format.

### Public Rust APIs

`Definition::new` builds the ordered layout; `DefinitionDocument` retains the full
annotated source. `encode`/`FrameEncoder` write PIL, `decode`/`decode_exact` read it,
and `FrameIndex` scans into reusable spans. `ArrayView` and `CborRef` support
borrowed access. `pac::PacIndex` validates decoded PAC member spans and common
fields without materializing objects. `compression::inflate` is feature-gated.

Development schema checks can also validate consumer profiles:

```sh
cargo run --locked --manifest-path rust/Cargo.toml --example check_definition -- schema.cddl definition.rx
```

This checks CDDL structure plus PIL layout semantics. It does not execute a
consumer's additional semantic validators. The CDDL tool is a dev dependency.

## License

[Apache-2.0](LICENSE).

### Shared Nested Schema Runtime

CDDL authoring compiles to binary PIL `.rx` documents containing their complete
structured schema. Rust `DefinitionDocument`, the Go bindings and `go/codec`
layouts, and the Rust WASM codec use the same interpreter for nested records,
arrays, named types, choices, sparse members, and constraints. Registration
rejects disagreement between the schema and its compiled root layout. Full
frame and resolved PAC validation checks nested children; explicit structural
APIs remain available for trusted, integrity-checked data.

Go exposes `EncodeJSON` and `DecodeJSON`; WASM's `Codec` exposes `encodeJSON` and
`decodeJSON`. Pass JSON text so 64-bit numbers never pass through a JavaScript
floating-point object. Native `.rx` bytes and annotations remain digest-bound.
Go's schema support links the Rust FFI library: build `rust/ffi` in release mode
before testing or consuming the Go package. CDDL source parsing is a separate
`schema` feature used by `rx`; runtime schema interpretation is enabled by
default. Keep CDDL compiler tests in `rust/tests/schema.rs`, `.rx` CLI behavior
in `rust/tests/rx.rs`, bootstrap Definition conformance in
`rust/tests/documents.rs`, and binding parity in `go/codec/schema_test.go` plus
`npm/test.mjs`. Application-specific profile tests belong with the application
that owns those semantics.
