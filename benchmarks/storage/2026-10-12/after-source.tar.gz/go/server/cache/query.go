package cache

import (
	"bytes"
	"container/heap"
	"context"
	"fmt"
	"time"
)

type Query struct {
	Branch   Branch
	From, To time.Time
	Equals   map[string]Value
}
type cursor struct{ at, end uint64 }
type cursors struct {
	values []cursor
	rows   []byte
	width  int
}

func (h cursors) Len() int { return len(h.values) }
func (h cursors) Less(i, j int) bool {
	a, b := h.values[i].at*uint64(h.width), h.values[j].at*uint64(h.width)
	return bytes.Compare(h.rows[a:a+16], h.rows[b:b+16]) < 0
}
func (h cursors) Swap(i, j int) { h.values[i], h.values[j] = h.values[j], h.values[i] }
func (h *cursors) Push(x any)   { h.values = append(h.values, x.(cursor)) }
func (h *cursors) Pop() any {
	n := len(h.values) - 1
	v := h.values[n]
	h.values = h.values[:n]
	return v
}
func (s *Store) frame(b *branchStore, row, dst []byte) ([]byte, error) {
	start, end := order.Uint64(row[s.row.Start:]), order.Uint64(row[s.row.End:])
	pop, e := readBytes(b.pop, start, end)
	if e != nil {
		return nil, e
	}
	var f Frame
	if e = s.layout.Scan(pop, &f); e != nil {
		return nil, e
	}
	if f.Values[s.layout.Event].State != Absent {
		return nil, fmt.Errorf("population shadows event_id")
	}
	f.Values[s.layout.Event] = Value{Direct, row[:16]}
	for j, role := range []int{s.layout.Object, s.layout.Revision} {
		if role < 0 {
			continue
		}
		state := State(row[s.row.Flags] >> uint(j*2) & 3)
		slot := s.row.Object
		if j == 1 {
			slot = s.row.Revision
		}
		if s.layout.Widths[role] > 0 && state == Direct {
			if f.Values[role].State != Absent {
				return nil, fmt.Errorf("population shadows indexed identity")
			}
			f.Values[role] = Value{Direct, row[slot : slot+s.layout.Widths[role]]}
		} else if f.Values[role].State != state {
			return nil, fmt.Errorf("identity state mismatch")
		}
	}
	if e = s.trie.expand(order.Uint16(row[s.row.Reference:]), f.Values); e != nil {
		return nil, e
	}
	return s.layout.Encode(dst, f.Values)
}
func (l *Layout) equal(i int, a, b Value) bool {
	if a.State == Absent || a.State == Null || b.State == Absent || b.State == Null {
		return a.State == b.State
	}
	field := l.Definition.Fields[i]
	if len(field.Values) > 0 {
		if a.State == Direct {
			n := unsigned(a.Bytes)
			if n >= uint64(len(field.Values)) {
				return false
			}
			a = Text(field.Values[n])
		}
		if b.State == Direct {
			n := unsigned(b.Bytes)
			if n >= uint64(len(field.Values)) {
				return false
			}
			b = Text(field.Values[n])
		}
	}
	return a.State == b.State && bytes.Equal(a.Bytes, b.Bytes)
}

// Search merges time-sorted runs; no assumption is made about global append
// order. Callback bytes are borrowed until the next callback. Source rows are
// stable logical addresses in the returned branch generation.
func (s *Store) Search(ctx context.Context, q Query, visit func(uint64, []byte) error) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if e := s.check(); e != nil {
		return e
	}
	if !q.Branch.Valid() || !q.From.Before(q.To) {
		return fmt.Errorf("invalid query")
	}
	b := s.branches[q.Branch]
	if b == nil {
		return nil
	}
	if e := s.flush(b); e != nil {
		return s.fail(e)
	}
	wanted := map[int]Value{}
	for key, v := range q.Equals {
		found := false
		for i, f := range s.layout.Definition.Fields {
			if f.Name == key {
				wanted[i] = v
				found = true
				break
			}
		}
		if !found {
			return fmt.Errorf("unknown predicate field %q", key)
		}
	}
	h := cursors{rows: b.rows, width: s.row.Width, values: b.candidates(q.From, q.To, s.row.Width)}
	heap.Init(&h)
	var output []byte
	var f Frame
	// Shared predicates are resolved once per referenced prefix, not per record.
	decisions := make([]uint8, len(s.trie.nodes))
	for h.Len() > 0 {
		if e := ctx.Err(); e != nil {
			return e
		}
		c := h.values[0]
		number := c.at
		row := b.rows[number*uint64(s.row.Width) : (number+1)*uint64(s.row.Width)]
		h.values[0].at++
		if h.values[0].at == c.end {
			heap.Pop(&h)
		} else {
			heap.Fix(&h, 0)
		}
		matchIndex := true
		if value, ok := wanted[s.layout.Event]; ok && !s.layout.equal(s.layout.Event, Value{Direct, row[:16]}, value) {
			matchIndex = false
		}
		for j, field := range []int{s.layout.Object, s.layout.Revision} {
			value, ok := wanted[field]
			if field < 0 || !ok || !matchIndex {
				continue
			}
			state := State(row[s.row.Flags] >> uint(2*j) & 3)
			actual := Value{State: state}
			if state >= Direct {
				slot := s.row.Object
				if j == 1 {
					slot = s.row.Revision
				}
				if w := s.layout.Widths[field]; w > 0 {
					actual.Bytes = row[slot : slot+w]
				} else {
					var e error
					actual.Bytes, e = s.identity(b, row, field, slot)
					if e != nil {
						return e
					}
				}
			}
			if !s.layout.equal(field, actual, value) {
				matchIndex = false
			}
		}
		if !matchIndex {
			continue
		}
		ref := order.Uint16(row[s.row.Reference:])
		if int(ref) >= len(decisions) {
			return fmt.Errorf("unknown shared reference")
		}
		if decisions[ref] == 0 {
			decisions[ref] = 1
			for p := ref; p != 0; p = s.trie.nodes[p].Parent {
				n := s.trie.nodes[p]
				if v, ok := wanted[int(n.Field)]; ok && !s.layout.equal(int(n.Field), Value{Direct, n.Bytes}, v) {
					decisions[ref] = 2
					break
				}
			}
		}
		if decisions[ref] == 2 {
			continue
		}
		var e error
		output, e = s.frame(b, row, output)
		if e != nil {
			return e
		}
		if len(wanted) > 0 {
			if e = s.layout.Scan(output, &f); e != nil {
				return e
			}
			match := true
			for i, v := range wanted {
				if !s.layout.equal(i, f.Values[i], v) {
					match = false
					break
				}
			}
			if !match {
				continue
			}
		}
		if e = visit(number, output); e != nil {
			return e
		}
	}
	return nil
}

// PeriodRanges returns a coherent committed snapshot. End=nil retains its
// source-tail meaning; consumers must resolve it against this returned tail.
func (s *Store) PeriodRanges(branch Branch, year, day int) ([]RowRange, uint64, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if e := s.check(); e != nil {
		return nil, 0, e
	}
	b := s.branches[branch]
	if b == nil {
		return nil, 0, nil
	}
	tail := uint64(len(b.rows) / s.row.Width)
	if p := b.time.years[year][day]; p != nil {
		out := append([]RowRange(nil), p.Ranges...)
		for i, r := range out {
			if r.End != nil {
				n := *r.End
				out[i].End = &n
			}
		}
		return out, tail, nil
	}
	return nil, tail, nil
}
