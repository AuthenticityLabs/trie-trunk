package cache

import (
	"bytes"
	"fmt"
	"sort"
	"time"
)

type RowLayout struct {
	Width, Object, Revision, Flags, Reference, Start, End int
	ObjectWidth, RevisionWidth                            int
}

func (l *Layout) RowLayout() RowLayout {
	r := RowLayout{Object: -1, Revision: -1}
	at := 16
	slot := func(field int) (int, int) {
		if field < 0 {
			return -1, 0
		}
		w := l.Widths[field]
		if w == 0 {
			w = 16
		}
		p := at
		at += w
		return p, w
	}
	r.Object, r.ObjectWidth = slot(l.Object)
	r.Revision, r.RevisionWidth = slot(l.Revision)
	r.Flags = at
	at += 2
	r.Reference = at
	at += 2
	r.Start = at
	at += 8
	r.End = at
	at += 8
	r.Width = at
	return r
}
func eventTime(id []byte) int64 {
	var v uint64
	for _, b := range id[:6] {
		v = v<<8 | uint64(b)
	}
	return int64(v)
}
func eventID(v Value) ([16]byte, error) {
	var id [16]byte
	if v.State != Direct || len(v.Bytes) != 16 || v.Bytes[6]>>4 != 7 || v.Bytes[8]>>6 != 2 {
		return id, fmt.Errorf("event_id must be UUIDv7")
	}
	copy(id[:], v.Bytes)
	return id, nil
}

type RowRange struct {
	Start uint64  `cbor:"0,keyasint" json:"start"`
	End   *uint64 `cbor:"1,keyasint" json:"end"`
}
type Period struct {
	Year     int `cbor:"0,keyasint" json:"year"`
	Day      int `cbor:"1,keyasint" json:"day"`
	From, To int64
	Ranges   []RowRange
}
type Run struct {
	Start    uint64 `cbor:"0,keyasint"`
	End      uint64 `cbor:"1,keyasint"`
	PopStart uint64 `cbor:"2,keyasint"`
	PopEnd   uint64 `cbor:"3,keyasint"`
	MinMS    int64  `cbor:"4,keyasint"`
	MaxMS    int64  `cbor:"5,keyasint"`
	IndexCRC uint32 `cbor:"6,keyasint"`
	PopCRC   uint32 `cbor:"7,keyasint"`
	TrieSize int    `cbor:"8,keyasint"`
}
type periodKey struct{ Year, Day int }
type timeTrie struct {
	years map[int]map[int]*Period
	last  *Period
}

func newTimeTrie() timeTrie { return timeTrie{years: map[int]map[int]*Period{}} }
func (t *timeTrie) append(ms int64, row uint64, location *time.Location) {
	now := time.UnixMilli(ms).In(location)
	year, day := now.Year(), now.YearDay()
	if t.last != nil && t.last.Year == year && t.last.Day == day {
		return
	}
	if t.last != nil {
		end := row
		t.last.Ranges[len(t.last.Ranges)-1].End = &end
	}
	days := t.years[year]
	if days == nil {
		days = map[int]*Period{}
		t.years[year] = days
	}
	p := days[day]
	if p == nil {
		from := time.Date(year, now.Month(), now.Day(), 0, 0, 0, 0, location)
		p = &Period{Year: year, Day: day, From: from.UnixMilli(), To: from.AddDate(0, 0, 1).UnixMilli()}
		days[day] = p
	}
	p.Ranges = append(p.Ranges, RowRange{Start: row})
	t.last = p
}
func (r RowRange) end(tail uint64) uint64 {
	if r.End == nil {
		return tail
	}
	return *r.End
}
func lower(rows []byte, w int, start, end uint64, ms int64) uint64 {
	for start < end {
		mid := start + (end-start)/2
		if eventTime(rows[mid*uint64(w):]) < ms {
			start = mid + 1
		} else {
			end = mid
		}
	}
	return start
}
func equalID(row []byte, id [16]byte) bool { return bytes.Equal(row[:16], id[:]) }

func timeBound(t time.Time) int64 {
	ms := t.UnixMilli()
	if t.Nanosecond()%1_000_000 != 0 {
		ms++
	}
	return ms
}
func (b *branchStore) candidates(from, to time.Time, width int) []cursor {
	lo, hi := timeBound(from), timeBound(to)
	tail := uint64(len(b.rows) / width)
	var spans []Span
	for _, days := range b.time.years {
		for _, period := range days {
			if period.To <= lo || period.From >= hi {
				continue
			}
			for _, r := range period.Ranges {
				spans = append(spans, Span{r.Start, r.end(tail)})
			}
		}
	}
	spans, _ = Normalize(spans)
	var out []cursor
	for _, span := range spans {
		first := sort.Search(len(b.runs), func(i int) bool { return b.runs[i].End > span.Start })
		for i := first; i < len(b.runs) && b.runs[i].Start < span.End; i++ {
			run := b.runs[i]
			if run.MaxMS < lo || run.MinMS >= hi {
				continue
			}
			start, end := run.Start, run.End
			if start < span.Start {
				start = span.Start
			}
			if end > span.End {
				end = span.End
			}
			left, right := lower(b.rows, width, start, end, lo), lower(b.rows, width, start, end, hi)
			if left < right {
				out = append(out, cursor{left, right})
			}
		}
	}
	return out
}
