package cache

import (
	"fmt"
	"math"
	"sort"
	"time"
)

type Aggregate struct{ Count, DurationCount, Sum, Min, Max uint64 }

func (a *Aggregate) add(duration *uint64) error {
	if a.Count == math.MaxUint64 {
		return fmt.Errorf("aggregate overflow")
	}
	a.Count++
	if duration == nil {
		return nil
	}
	n := *duration
	if math.MaxUint64-a.Sum < n || a.DurationCount == math.MaxUint64 {
		return fmt.Errorf("aggregate overflow")
	}
	if a.DurationCount == 0 || n < a.Min {
		a.Min = n
	}
	if a.DurationCount == 0 || n > a.Max {
		a.Max = n
	}
	a.Sum += n
	a.DurationCount++
	return nil
}
func (a *Aggregate) merge(b Aggregate) error {
	if math.MaxUint64-a.Count < b.Count || math.MaxUint64-a.DurationCount < b.DurationCount || math.MaxUint64-a.Sum < b.Sum {
		return fmt.Errorf("aggregate overflow")
	}
	if b.DurationCount > 0 {
		if a.DurationCount == 0 || b.Min < a.Min {
			a.Min = b.Min
		}
		if a.DurationCount == 0 || b.Max > a.Max {
			a.Max = b.Max
		}
	}
	a.Count += b.Count
	a.DurationCount += b.DurationCount
	a.Sum += b.Sum
	return nil
}

type aggregateKey struct {
	Period    int64
	Reference uint16
}
type Group struct {
	Period    int64     `cbor:"0,keyasint"`
	Reference uint16    `cbor:"1,keyasint"`
	Aggregate Aggregate `cbor:"2,keyasint"`
}
type Summary struct {
	From, Through uint64
	Groups        []Group
}

func makeSummary(run Run, groups map[aggregateKey]Aggregate) Summary {
	s := Summary{From: run.Start, Through: run.End}
	for k, a := range groups {
		s.Groups = append(s.Groups, Group{k.Period, k.Reference, a})
	}
	sort.Slice(s.Groups, func(i, j int) bool {
		a, b := s.Groups[i], s.Groups[j]
		if a.Period != b.Period {
			return a.Period < b.Period
		}
		return a.Reference < b.Reference
	})
	return s
}

// The summary journal is a durable accumulator. Only complete five-minute
// periods ending at least fifteen minutes ago are exposed as finalized. Late
// commits add deltas at new row watermarks; a retry never reapplies a delta.
func (s *Store) Summaries(branch Branch, from, to time.Time) (map[int64]map[uint16]Aggregate, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.summaries(branch, from, to)
}
func (s *Store) summaries(branch Branch, from, to time.Time) (map[int64]map[uint16]Aggregate, error) {
	if e := s.check(); e != nil {
		return nil, e
	}
	if !branch.Valid() || !branch.Aggregates() {
		return nil, fmt.Errorf("branch does not aggregate")
	}
	out := map[int64]map[uint16]Aggregate{}
	b := s.branches[branch]
	if b == nil {
		return out, nil
	}
	if e := s.flush(b); e != nil {
		return nil, s.fail(e)
	}
	cutoff := s.config.Now().Add(-15 * time.Minute).UnixMilli()
	var through uint64
	for _, summary := range b.summaries {
		if summary.From != through || summary.Through <= through {
			return nil, fmt.Errorf("summary watermark mismatch")
		}
		through = summary.Through
		for _, g := range summary.Groups {
			if g.Period < from.UnixMilli() || g.Period >= to.UnixMilli() || g.Period+300000 > cutoff {
				continue
			}
			groups := out[g.Period]
			if groups == nil {
				groups = map[uint16]Aggregate{}
				out[g.Period] = groups
			}
			a := groups[g.Reference]
			if e := a.merge(g.Aggregate); e != nil {
				return nil, e
			}
			groups[g.Reference] = a
		}
	}
	return out, nil
}
