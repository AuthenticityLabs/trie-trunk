package cache

import (
	"context"
	"crypto/sha256"
	"fmt"
	"sort"
	"time"
)

type Span struct{ Start, End uint64 }

func Normalize(spans []Span) ([]Span, error) {
	out := append([]Span(nil), spans...)
	for _, r := range out {
		if r.End <= r.Start {
			return nil, fmt.Errorf("invalid coverage span")
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Start < out[j].Start })
	n := 0
	for _, r := range out {
		if n > 0 && r.Start <= out[n-1].End {
			if r.End > out[n-1].End {
				out[n-1].End = r.End
			}
		} else {
			out[n] = r
			n++
		}
	}
	return out[:n], nil
}
func Missing(wanted, have []Span) ([]Span, error) {
	want, e := Normalize(wanted)
	if e != nil {
		return nil, e
	}
	have, e = Normalize(have)
	if e != nil {
		return nil, e
	}
	var out []Span
	j := 0
	for _, w := range want {
		at := w.Start
		for j < len(have) && have[j].End <= at {
			j++
		}
		for k := j; k < len(have) && have[k].Start < w.End; k++ {
			h := have[k]
			if h.Start > at {
				out = append(out, Span{at, h.Start})
			}
			if h.End > at {
				at = h.End
			}
			if at >= w.End {
				break
			}
		}
		if at < w.End {
			out = append(out, Span{at, w.End})
		}
	}
	return out, nil
}

type Coverage struct {
	Definition        [32]byte
	Generation        [16]byte
	Index, Population []Span
	TrieNodes         int
}
type CollectionRequest struct {
	Branch                       Branch
	Day                          time.Time
	PopulationFrom, PopulationTo time.Time
	Have                         Coverage
}
type Manifest struct {
	Definition  [32]byte
	Generation  [16]byte
	Branch      Branch
	From, To    time.Time
	Tail        uint64
	Checkpoint  uint64
	RowWidth    int
	TrieNodes   int
	Index       []Span
	Population  []Span
	Provisional bool
}
type NativeChunk struct {
	Kind   string
	Start  uint64
	Data   []byte
	Digest [32]byte
}

// Collect publishes the source manifest first, then dependencies and missing
// native ranges. The caller must persist all chunks and the completion result
// before certifying coverage. A successful empty manifest certifies known-empty
// coverage at this checkpoint; an interrupted stream certifies nothing new.
func (s *Store) Collect(ctx context.Context, request CollectionRequest, manifest func(Manifest) error, send func(NativeChunk) error) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if e := s.check(); e != nil {
		return e
	}
	if !request.Branch.Valid() {
		return fmt.Errorf("invalid branch")
	}
	if len(request.Have.Index) > 10000 || len(request.Have.Population) > 10000 {
		return fmt.Errorf("coverage advertisement too large")
	}
	day := request.Day.In(s.location)
	from := time.Date(day.Year(), day.Month(), day.Day(), 0, 0, 0, 0, s.location)
	to := from.AddDate(0, 0, 1)
	b, e := s.openBranch(request.Branch)
	if e != nil {
		return s.fail(e)
	}
	if e = s.flush(b); e != nil {
		return s.fail(e)
	}
	m := Manifest{Definition: s.layout.Digest, Generation: b.generation, Branch: request.Branch, From: from, To: to, Tail: uint64(len(b.rows) / s.row.Width), Checkpoint: uint64(len(b.runs)), RowWidth: s.row.Width, TrieNodes: len(s.trie.nodes), Provisional: to.After(s.config.Now().Add(-15 * time.Minute))}
	if p := b.time.years[from.Year()][from.YearDay()]; p != nil {
		for _, r := range p.Ranges {
			m.Index = append(m.Index, Span{r.Start, r.end(m.Tail)})
		}
	}
	m.Index, e = Normalize(m.Index)
	if e != nil {
		return e
	}
	popFrom, popTo := request.PopulationFrom, request.PopulationTo
	if !popFrom.IsZero() || !popTo.IsZero() {
		if !popFrom.Before(popTo) || popFrom.Before(from) || popTo.After(to) {
			return fmt.Errorf("population window must lie in collection day")
		}
		for _, r := range m.Index {
			for n := r.Start; n < r.End; n++ {
				row := b.rows[n*uint64(s.row.Width) : (n+1)*uint64(s.row.Width)]
				ms := eventTime(row)
				if ms >= popFrom.UnixMilli() && ms < popTo.UnixMilli() {
					m.Population = append(m.Population, Span{order.Uint64(row[s.row.Start:]), order.Uint64(row[s.row.End:])})
				}
			}
		}
		m.Population, e = Normalize(m.Population)
		if e != nil {
			return e
		}
	}
	have := request.Have
	if have.Definition != m.Definition {
		have = Coverage{}
	} else if have.Generation != m.Generation {
		have.Index = nil
		have.Population = nil
	}
	missingIndex, e := Missing(m.Index, have.Index)
	if e != nil {
		return e
	}
	missingPop, e := Missing(m.Population, have.Population)
	if e != nil {
		return e
	}
	if have.TrieNodes < 0 || have.TrieNodes > len(s.trie.nodes) {
		return fmt.Errorf("invalid cached trie prefix")
	}
	if e = manifest(m); e != nil {
		return e
	}
	emit := func(kind string, start uint64, data []byte) error {
		if e := ctx.Err(); e != nil {
			return e
		}
		return send(NativeChunk{kind, start, data, sha256.Sum256(data)})
	}
	if request.Have.Definition != m.Definition {
		if e = emit("map", 0, s.layout.Bytes); e != nil {
			return e
		}
	}
	first := have.TrieNodes
	if first < 1 {
		first = 1
	}
	if first < len(s.trie.nodes) {
		raw, e := encoder.Marshal(s.trie.nodes[first:])
		if e != nil {
			return e
		}
		if e = emit("trie", uint64(first), raw); e != nil {
			return e
		}
	}
	// State is independent of diagnostic subscriptions and payload retention.
	type tokenEntry struct {
		ID    []byte
		Token uint64
	}
	var entries []tokenEntry
	for id, token := range s.state.objects {
		entries = append(entries, tokenEntry{[]byte(id), token})
	}
	sort.Slice(entries, func(i, j int) bool { return string(entries[i].ID) < string(entries[j].ID) })
	control, e := encoder.Marshal(struct {
		Epoch                [16]byte
		Sequence, Collection uint64
		Objects              []tokenEntry
	}{s.state.epoch, s.state.sequence, s.state.collection, entries})
	if e != nil {
		return e
	}
	if e = emit("state", 0, control); e != nil {
		return e
	}
	const maxChunk = 1 << 20
	for _, r := range missingIndex {
		for at := r.Start; at < r.End; {
			end := at + maxChunk/uint64(s.row.Width)
			if end > r.End {
				end = r.End
			}
			if e = emit("index", at, b.rows[at*uint64(s.row.Width):end*uint64(s.row.Width)]); e != nil {
				return e
			}
			at = end
		}
	}
	for _, r := range missingPop {
		for at := r.Start; at < r.End; {
			end := at + maxChunk
			if end > r.End {
				end = r.End
			}
			raw, e := readBytes(b.pop, at, end)
			if e != nil {
				return e
			}
			if e = emit("population", at, raw); e != nil {
				return e
			}
			at = end
		}
	}
	return nil
}

// Extents use byte offsets (convert row numbers using the declared row width).
// They map packed local bytes to stable source addresses. A gap fill appends
// data and another extent; it never moves existing bytes or allocates fake holes.
type Extent struct {
	Source     Span
	LocalStart uint64
}

func Resolve(extents []Extent, wanted Span) ([]Extent, error) {
	if wanted.End <= wanted.Start {
		return nil, fmt.Errorf("invalid requested extent")
	}
	sorted := append([]Extent(nil), extents...)
	sort.Slice(sorted, func(i, j int) bool { return sorted[i].Source.Start < sorted[j].Source.Start })
	at := wanted.Start
	var out []Extent
	for i, e := range sorted {
		if e.Source.End <= e.Source.Start || i > 0 && e.Source.Start < sorted[i-1].Source.End {
			return nil, fmt.Errorf("invalid or overlapping local extents")
		}
		if e.Source.End <= at || e.Source.Start >= wanted.End {
			continue
		}
		if e.Source.Start > at {
			return nil, fmt.Errorf("source gap")
		}
		end := e.Source.End
		if end > wanted.End {
			end = wanted.End
		}
		out = append(out, Extent{Span{at, end}, e.LocalStart + (at - e.Source.Start)})
		at = end
	}
	if at != wanted.End {
		return nil, fmt.Errorf("source gap")
	}
	return out, nil
}
