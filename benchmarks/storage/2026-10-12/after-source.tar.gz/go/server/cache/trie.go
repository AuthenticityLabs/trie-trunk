package cache

import "fmt"

type sharedNode struct {
	Parent uint16 `cbor:"0,keyasint"`
	Field  uint16 `cbor:"1,keyasint"`
	Bytes  []byte `cbor:"2,keyasint"`
}
type sharedKey struct {
	Parent uint16
	Field  uint16
	Bytes  string
}
type sharedTrie struct {
	nodes     []sharedNode
	edges     map[sharedKey]uint16
	persisted int
}

func newTrie() sharedTrie {
	return sharedTrie{nodes: []sharedNode{{}}, edges: map[sharedKey]uint16{}, persisted: 1}
}
func (t *sharedTrie) add(n sharedNode, l *Layout) error {
	if len(t.nodes) >= 65536 || int(n.Parent) >= len(t.nodes) || int(n.Field) >= len(l.Widths) || len(n.Bytes) != l.Widths[n.Field] || len(n.Bytes) == 0 {
		return fmt.Errorf("invalid shared node")
	}
	depth := 0
	for p := n.Parent; p != 0; p = t.nodes[p].Parent {
		depth++
	}
	if depth >= len(l.Path) || l.Path[depth] != int(n.Field) {
		return fmt.Errorf("invalid shared path")
	}
	key := sharedKey{n.Parent, n.Field, string(n.Bytes)}
	if _, ok := t.edges[key]; ok {
		return fmt.Errorf("duplicate shared node")
	}
	n.Bytes = append([]byte(nil), n.Bytes...)
	t.edges[key] = uint16(len(t.nodes))
	t.nodes = append(t.nodes, n)
	return nil
}

// Only the present contiguous prefix is shared. Absent/NULL/literal fields stop
// the path; expansion never turns an absent PATCH field into an assignment.
func (t *sharedTrie) intern(l *Layout, v []Value) uint16 {
	var parent uint16
	for _, i := range l.Path {
		if v[i].State != Direct {
			break
		}
		k := sharedKey{parent, uint16(i), string(v[i].Bytes)}
		next, ok := t.edges[k]
		if !ok {
			if len(t.nodes) == 65536 {
				break
			}
			next = uint16(len(t.nodes))
			t.nodes = append(t.nodes, sharedNode{parent, uint16(i), append([]byte(nil), v[i].Bytes...)})
			t.edges[k] = next
		}
		parent = next
	}
	return parent
}
func (t *sharedTrie) remove(ref uint16, v []Value) {
	for ref != 0 {
		n := t.nodes[ref]
		v[n.Field] = Value{}
		ref = n.Parent
	}
}
func (t *sharedTrie) expand(ref uint16, v []Value) error {
	if int(ref) >= len(t.nodes) {
		return fmt.Errorf("unknown shared reference")
	}
	for ref != 0 {
		n := t.nodes[ref]
		if v[n.Field].State != Absent {
			return fmt.Errorf("population shadows shared reference")
		}
		v[n.Field] = Value{Direct, n.Bytes}
		ref = n.Parent
	}
	return nil
}
